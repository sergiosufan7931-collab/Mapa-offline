plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mapaoffline.gps"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mapaoffline.gps"
        minSdk = 26
        targetSdk = 34
        // Sube sola con cada compilación en GitHub, así cada APK nueva se instala encima de la anterior.
        versionCode = 1000 + (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0)
        versionName = "0.3"
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    // Firma fija: la misma clave en todas las versiones. Si se cambia, Android obliga a desinstalar para actualizar.
    signingConfigs {
        create("fija") {
            storeFile = file("mapa.jks")
            storePassword = "85aa37ec3a739d50266198b5"
            keyAlias = "mapa"
            keyPassword = "85aa37ec3a739d50266198b5"
        }
    }

    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("fija")
            isMinifyEnabled = false
        }
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fija")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    packaging {
        resources {
            excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "META-INF/DEPENDENCIES")
        }
    }
}

dependencies {
    val mapsforge = "0.21.0"
    implementation("org.mapsforge:mapsforge-core:$mapsforge")
    implementation("org.mapsforge:mapsforge-map:$mapsforge")
    implementation("org.mapsforge:mapsforge-map-reader:$mapsforge")
    implementation("org.mapsforge:mapsforge-themes:$mapsforge")
    implementation("org.mapsforge:mapsforge-map-android:$mapsforge")
    implementation("com.caverock:androidsvg:1.4")
}
