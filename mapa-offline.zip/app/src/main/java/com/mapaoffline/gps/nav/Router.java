package com.mapaoffline.gps.nav;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Calcula rutas por las calles (A*) y arma las indicaciones. Funciona sin conexión. */
public final class Router {
    private final NavData d;

    private static final double VMAX = 80.0 / 3.6;     // m/s: la velocidad más alta del modelo (para el A*)
    private static final double RETRASO_CRUCE = 2.0;   // segundos por cruce
    private static final double PENA_CONTRAMANO = 40.0; // segundos si hay que salir en sentido contrario al rumbo

    public Router(NavData datos) { this.d = datos; }

    private static final class Tramo {
        int tramo; boolean atras; double f0, f1;
        Tramo(int t, boolean a, double f0, double f1) { tramo = t; atras = a; this.f0 = f0; this.f1 = f1; }
    }

    private int modo(int l) { return (d.lFlags[l] >> 4) & 3; }

    /** Ruta entre dos puntos cualesquiera. rumbo = hacia dónde mira quien sale (grados) o -1 si no se sabe. */
    public Route ruta(double lat1, double lon1, double lat2, double lon2, double rumbo) throws RutaException {
        NavData.Punto s = d.ubicar(lat1, lon1, 1000);
        if (s == null) throw new RutaException("Tu posición está lejos de las calles del mapa.");
        NavData.Punto t = d.ubicar(lat2, lon2, 1000);
        if (t == null) throw new RutaException("El destino está fuera del mapa o lejos de una calle.");
        return ruta(s, t, rumbo);
    }

    public Route ruta(NavData.Punto s, NavData.Punto t, double rumbo) throws RutaException {
        int nV = d.nV;
        double[] g = new double[nV];
        Arrays.fill(g, Double.MAX_VALUE);
        int[] prev = new int[nV];
        Arrays.fill(prev, -100);
        boolean[] cerrado = new boolean[nV];
        Heap heap = new Heap();

        final int ls = s.tramo, ld = t.tramo;
        final double fs = s.fraccion, fd = t.fraccion;
        final double cs = d.lCost[ls] / 10.0, cd = d.lCost[ld] / 10.0;
        final int ms = modo(ls), md = modo(ld);
        final double tLat = t.lat, tLon = t.lon;

        double mejor = Double.MAX_VALUE;
        int mejorV = -1, mejorVia = 0;

        if (ls == ld) {
            if (fd >= fs && (ms == 0 || ms == 1)) { mejor = (fd - fs) * cs; mejorV = -3; mejorVia = 0; }
            else if (fd < fs && (ms == 0 || ms == 2)) { mejor = (fs - fd) * cs; mejorV = -3; mejorVia = 1; }
        }

        double penB = 0, penA = 0;
        if (rumbo >= 0) {
            double rb = rumboEn(ls, fs);
            if (Math.abs(Geo.giro(rumbo, rb)) > 100) penB = PENA_CONTRAMANO;
            if (Math.abs(Geo.giro(rumbo, rb + 180)) > 100) penA = PENA_CONTRAMANO;
        }
        if (ms == 0 || ms == 1) {
            int v = d.lB[ls];
            double c = (1 - fs) * cs + penB;
            if (c < g[v]) { g[v] = c; prev[v] = -10; heap.push(c + h(v, tLat, tLon), v); }
        }
        if (ms == 0 || ms == 2) {
            int v = d.lA[ls];
            double c = fs * cs + penA;
            if (c < g[v]) { g[v] = c; prev[v] = -11; heap.push(c + h(v, tLat, tLon), v); }
        }

        while (heap.size > 0) {
            if (heap.topKey() >= mejor) break;
            int v = heap.pop();
            if (cerrado[v]) continue;
            cerrado[v] = true;
            if (v == d.lA[ld] && (md == 0 || md == 1)) {
                double tot = g[v] + fd * cd;
                if (tot < mejor) { mejor = tot; mejorV = v; mejorVia = 0; }
            }
            if (v == d.lB[ld] && (md == 0 || md == 2)) {
                double tot = g[v] + (1 - fd) * cd;
                if (tot < mejor) { mejor = tot; mejorV = v; mejorVia = 1; }
            }
            for (int k = d.adjStart[v]; k < d.adjStart[v + 1]; k++) {
                int e = d.adjEntry[k];
                int l = e >> 1;
                int w = (e & 1) == 0 ? d.lB[l] : d.lA[l];
                if (cerrado[w]) continue;
                double ng = g[v] + d.lCost[l] / 10.0 + RETRASO_CRUCE;
                if (ng < g[w]) {
                    g[w] = ng;
                    prev[w] = e;
                    heap.push(ng + h(w, tLat, tLon), w);
                }
            }
        }
        if (mejor == Double.MAX_VALUE) throw new RutaException("No encontré un camino entre los dos puntos.");

        // reconstruir los tramos recorridos
        ArrayList<Tramo> tr = new ArrayList<Tramo>();
        if (mejorV == -3) {
            tr.add(new Tramo(ls, mejorVia == 1, fs, fd));
        } else {
            tr.add(mejorVia == 0 ? new Tramo(ld, false, 0, fd) : new Tramo(ld, true, 1, fd));
            int v = mejorV;
            while (true) {
                int e = prev[v];
                if (e == -10) { tr.add(new Tramo(ls, false, fs, 1)); break; }
                if (e == -11) { tr.add(new Tramo(ls, true, fs, 0)); break; }
                int l = e >> 1;
                boolean atras = (e & 1) == 1;
                tr.add(new Tramo(l, atras, atras ? 1 : 0, atras ? 0 : 1));
                v = atras ? d.lB[l] : d.lA[l];
            }
            Collections.reverse(tr);
        }
        return armar(tr);
    }

    private double h(int v, double tLat, double tLon) {
        return Geo.dist(d.vLat[v] * 1e-6, d.vLon[v] * 1e-6, tLat, tLon) / VMAX;
    }

    /** Rumbo del tramo (de A hacia B) en el punto dado por la fracción. */
    private double rumboEn(int l, double frac) {
        int n = d.puntos(l);
        double[] la = new double[n], lo = new double[n], cum = new double[n];
        for (int i = 0; i < n; i++) {
            la[i] = d.latDe(l, i) * 1e-6;
            lo[i] = d.lonDe(l, i) * 1e-6;
            if (i > 0) cum[i] = cum[i - 1] + Geo.dist(la[i - 1], lo[i - 1], la[i], lo[i]);
        }
        double objetivo = frac * cum[n - 1];
        int i = 0;
        while (i < n - 2 && cum[i + 1] < objetivo) i++;
        return Geo.rumbo(la[i], lo[i], la[i + 1], lo[i + 1]);
    }

    // ------------------------------------------------------------------ armado de la ruta

    private static final class Geom { ArrayList<double[]> p = new ArrayList<double[]>(); }

    private Geom geometria(Tramo t) {
        int l = t.tramo;
        int n = d.puntos(l);
        double[] la = new double[n], lo = new double[n], cum = new double[n];
        for (int i = 0; i < n; i++) {
            la[i] = d.latDe(l, i) * 1e-6;
            lo[i] = d.lonDe(l, i) * 1e-6;
            if (i > 0) cum[i] = cum[i - 1] + Geo.dist(la[i - 1], lo[i - 1], la[i], lo[i]);
        }
        double total = cum[n - 1];
        double a = Math.min(t.f0, t.f1) * total, b = Math.max(t.f0, t.f1) * total;
        Geom g = new Geom();
        g.p.add(en(la, lo, cum, a));
        for (int i = 1; i < n - 1; i++) if (cum[i] > a + 0.01 && cum[i] < b - 0.01) g.p.add(new double[]{la[i], lo[i]});
        g.p.add(en(la, lo, cum, b));
        if (t.atras) Collections.reverse(g.p);
        return g;
    }

    private static double[] en(double[] la, double[] lo, double[] cum, double dist) {
        int n = la.length;
        if (dist <= 0) return new double[]{la[0], lo[0]};
        if (dist >= cum[n - 1]) return new double[]{la[n - 1], lo[n - 1]};
        int i = 0;
        while (i < n - 2 && cum[i + 1] < dist) i++;
        double seg = cum[i + 1] - cum[i];
        double f = seg < 1e-9 ? 0 : (dist - cum[i]) / seg;
        return new double[]{la[i] + (la[i + 1] - la[i]) * f, lo[i] + (lo[i + 1] - lo[i]) * f};
    }

    private static double largo(Geom g) {
        double s = 0;
        for (int i = 1; i < g.p.size(); i++) s += Geo.dist(g.p.get(i - 1)[0], g.p.get(i - 1)[1], g.p.get(i)[0], g.p.get(i)[1]);
        return s;
    }

    /** Rumbo al final del tramo, mirando unos 15 m hacia atrás. */
    private static double rumboFinal(Geom g) {
        double[] fin = g.p.get(g.p.size() - 1);
        for (int i = g.p.size() - 2; i >= 0; i--) {
            double[] q = g.p.get(i);
            if (Geo.dist(q[0], q[1], fin[0], fin[1]) >= 15 || i == 0) return Geo.rumbo(q[0], q[1], fin[0], fin[1]);
        }
        return 0;
    }

    /** Rumbo al comienzo del tramo, mirando unos 15 m hacia adelante. */
    private static double rumboInicial(Geom g) {
        double[] ini = g.p.get(0);
        for (int i = 1; i < g.p.size(); i++) {
            double[] q = g.p.get(i);
            if (Geo.dist(ini[0], ini[1], q[0], q[1]) >= 15 || i == g.p.size() - 1) return Geo.rumbo(ini[0], ini[1], q[0], q[1]);
        }
        return 0;
    }

    private boolean esRotonda(int l) { return ((d.lFlags[l] >> 6) & 1) == 1; }

    private String nombre(int l) {
        int n = d.lName[l];
        return n >= 0 ? d.names[n] : "";
    }

    /** ¿Se puede salir de este vértice por una calle que no sea la rotonda? */
    private boolean saleDeRotonda(int v) {
        for (int k = d.adjStart[v]; k < d.adjStart[v + 1]; k++) if (!esRotonda(d.adjEntry[k] >> 1)) return true;
        return false;
    }

    private Route armar(List<Tramo> bruto) throws RutaException {
        ArrayList<Tramo> tr = new ArrayList<Tramo>();
        ArrayList<Geom> gs = new ArrayList<Geom>();
        for (Tramo t : bruto) {
            Geom g = geometria(t);
            if (largo(g) < 0.5) continue;
            tr.add(t);
            gs.add(g);
        }
        if (tr.isEmpty()) throw new RutaException("Ya estás en el destino.");

        Route r = new Route();
        ArrayList<double[]> pts = new ArrayList<double[]>();
        int[] inicio = new int[tr.size()];
        double tiempo = 0;
        for (int i = 0; i < tr.size(); i++) {
            Geom g = gs.get(i);
            inicio[i] = pts.size();
            for (int k = 0; k < g.p.size(); k++) {
                double[] q = g.p.get(k);
                if (k == 0 && !pts.isEmpty()) {
                    double[] u = pts.get(pts.size() - 1);
                    if (Geo.dist(u[0], u[1], q[0], q[1]) < 0.5) { inicio[i] = pts.size() - 1; continue; }
                }
                pts.add(q);
            }
            Tramo t = tr.get(i);
            tiempo += Math.abs(t.f1 - t.f0) * d.lCost[t.tramo] / 10.0 + RETRASO_CRUCE;
        }
        int n = pts.size();
        r.lat = new double[n]; r.lon = new double[n]; r.cum = new double[n];
        for (int i = 0; i < n; i++) {
            r.lat[i] = pts.get(i)[0];
            r.lon[i] = pts.get(i)[1];
            if (i > 0) r.cum[i] = r.cum[i - 1] + Geo.dist(r.lat[i - 1], r.lon[i - 1], r.lat[i], r.lon[i]);
        }
        r.distancia = r.cum[n - 1];
        r.tiempo = tiempo;

        // indicaciones
        Route.Paso salida = new Route.Paso();
        salida.tipo = Route.SALIDA;
        salida.calle = nombre(tr.get(0).tramo);
        salida.lat = r.lat[0]; salida.lon = r.lon[0]; salida.desde = 0;
        r.pasos.add(salida);

        boolean enRotonda = false;
        int salidas = 0;
        for (int i = 0; i + 1 < tr.size(); i++) {
            Tramo a = tr.get(i), b = tr.get(i + 1);
            int v = a.atras ? d.lA[a.tramo] : d.lB[a.tramo];
            int idx = inicio[i + 1];
            boolean rotA = esRotonda(a.tramo), rotB = esRotonda(b.tramo);
            if (!rotA && rotB) { enRotonda = true; salidas = 0; continue; }
            if (rotA && rotB) { if (saleDeRotonda(v)) salidas++; continue; }
            Route.Paso p = new Route.Paso();
            p.lat = r.lat[idx]; p.lon = r.lon[idx]; p.desde = r.cum[idx];
            p.calle = nombre(b.tramo);
            if (rotA && !rotB) {
                p.tipo = Route.ROTONDA;
                p.salida = salidas + 1;
                enRotonda = false;
                r.pasos.add(p);
                continue;
            }
            double giro = Geo.giro(rumboFinal(gs.get(i)), rumboInicial(gs.get(i + 1)));
            // otras salidas posibles en este cruce (sin contar la vuelta atrás ni la que se toma)
            int alt = 0;
            int volver = a.tramo * 2 + (a.atras ? 0 : 1);
            int tomar = b.tramo * 2 + (b.atras ? 1 : 0);
            for (int k = d.adjStart[v]; k < d.adjStart[v + 1]; k++) {
                int e = d.adjEntry[k];
                if (e != volver && e != tomar) alt++;
            }
            boolean otroNombre = !nombre(a.tramo).equals(p.calle) && !p.calle.isEmpty();
            double ab = Math.abs(giro);
            if (ab < 20 || (ab < 50 && alt == 0)) {
                if (!otroNombre) continue;
                p.tipo = Route.SEGUI;
            } else if (ab < 50) {
                p.tipo = giro > 0 ? Route.LIG_DER : Route.LIG_IZQ;
            } else if (ab < 125) {
                p.tipo = giro > 0 ? Route.DER : Route.IZQ;
            } else if (ab < 165) {
                p.tipo = giro > 0 ? Route.BRUSCO_DER : Route.BRUSCO_IZQ;
            } else {
                p.tipo = Route.GIRO_U;
            }
            r.pasos.add(p);
        }
        Route.Paso fin = new Route.Paso();
        fin.tipo = Route.LLEGADA;
        fin.lat = r.lat[n - 1]; fin.lon = r.lon[n - 1]; fin.desde = r.distancia;
        r.pasos.add(fin);
        for (int i = 0; i + 1 < r.pasos.size(); i++) r.pasos.get(i).distancia = r.pasos.get(i + 1).desde - r.pasos.get(i).desde;
        return r;
    }

    /** Cola de prioridad mínima con enteros. */
    private static final class Heap {
        double[] key = new double[1024];
        int[] val = new int[1024];
        int size = 0;

        double topKey() { return key[0]; }

        void push(double k, int v) {
            if (size == key.length) {
                key = Arrays.copyOf(key, size * 2);
                val = Arrays.copyOf(val, size * 2);
            }
            int i = size++;
            while (i > 0) {
                int p = (i - 1) >> 1;
                if (key[p] <= k) break;
                key[i] = key[p]; val[i] = val[p];
                i = p;
            }
            key[i] = k; val[i] = v;
        }

        int pop() {
            int res = val[0];
            size--;
            if (size > 0) {
                double k = key[size];
                int v = val[size];
                int i = 0;
                while (true) {
                    int c = 2 * i + 1;
                    if (c >= size) break;
                    if (c + 1 < size && key[c + 1] < key[c]) c++;
                    if (key[c] >= k) break;
                    key[i] = key[c]; val[i] = val[c];
                    i = c;
                }
                key[i] = k; val[i] = v;
            }
            return res;
        }
    }
}
