package com.mapaoffline.gps

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.mapaoffline.gps.nav.NavData
import com.mapaoffline.gps.nav.Route
import com.mapaoffline.gps.nav.RutaException
import com.mapaoffline.gps.nav.Router
import com.mapaoffline.gps.nav.Searcher
import org.mapsforge.core.model.LatLong
import org.mapsforge.core.model.Point
import org.mapsforge.map.android.graphics.AndroidGraphicFactory
import org.mapsforge.map.android.util.AndroidUtil
import org.mapsforge.map.android.view.MapView
import org.mapsforge.map.layer.cache.TileCache
import org.mapsforge.map.layer.overlay.Marker
import org.mapsforge.map.layer.overlay.Polyline
import org.mapsforge.map.layer.renderer.TileRendererLayer
import org.mapsforge.map.reader.MapFile
import org.mapsforge.map.rendertheme.InternalRenderTheme
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Fase 1: mapa sin conexión + ubicación GPS.
 * - El mapa se baja una vez con internet (o se elige un archivo .map) y después se usa sin conexión.
 * - La ubicación viene del GPS del teléfono y no se envía a ningún lado.
 */
class MainActivity : Activity() {

    private enum class Estado { SIN_MAPA, BAJANDO, LISTO }

    private val main = Handler(Looper.getMainLooper())

    private lateinit var mapView: MapView
    private lateinit var estado: TextView
    private lateinit var panel: LinearLayout
    private lateinit var botones: LinearLayout

    private var tileCache: TileCache? = null
    private var capaMapa: TileRendererLayer? = null
    private var marcador: Marker? = null
    private var ubicacion: Location? = null
    private var ultimaFijacion = 0L
    private var seguir = true
    private var mapaActual: File? = null

    private var estadoApp = Estado.SIN_MAPA
    private var bajada: Downloader? = null
    private var barra: ProgressBar? = null
    private var textoProgreso: TextView? = null
    private var mensajeError: String? = null
    private var tituloBajada: TextView? = null
    private var bajandoRutas = false

    // rutas y buscador (se cargan del archivo .nav del mapa)
    private class NavKit(val datos: NavData, val router: Router, val buscador: Searcher)
    private var navKit: NavKit? = null
    private var cargandoNav = false

    private lateinit var arriba: LinearLayout
    private lateinit var campo: EditText
    private lateinit var scrollResultados: ScrollView
    private lateinit var listaResultados: LinearLayout
    private lateinit var panelRuta: LinearLayout
    private lateinit var bannerNav: LinearLayout
    private lateinit var flechaNav: TextView
    private lateinit var distNav: TextView
    private lateinit var textoNav: TextView
    private var resumenNav: TextView? = null
    private var botonVoz: Button? = null

    private var hayDestino = false
    private var destLat = 0.0
    private var destLon = 0.0
    private var destTitulo = ""
    private var ruta: Route? = null
    private var capaRuta: Polyline? = null
    private var capaDestino: Marker? = null
    private val pines = ArrayList<Marker>()
    private var lugaresPines: List<Searcher.Lugar> = emptyList()
    private lateinit var barraPines: LinearLayout
    private lateinit var textoPines: TextView
    private var calculando = false

    private var navegando = false
    private var segmentoActual = 0
    private var fueraCont = 0
    private var ultimoReruteo = 0L
    private val anunciados = HashSet<Int>()
    private var vozActiva = true
    private var tts: TextToSpeech? = null
    private var ttsListo = false

    // cursor que representa tu posición (se elige en el botón ▲)
    private val estilos = listOf("Punto", "Flecha", "Moto", "Auto", "Camioneta")
    private var cursorEstilo = 1
    private var rumboCursor = 0f
    private var rumboDibujado = -999f
    private var estiloDibujado = -1

    private val lm by lazy { getSystemService(LOCATION_SERVICE) as LocationManager }
    private var gpsActivo = false

    private val oyente = object : LocationListener {
        override fun onLocationChanged(l: Location) { alRecibirUbicacion(l) }
        @Deprecated("Solo para Android anterior a 10")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) { actualizarEstadoGps() }
        override fun onProviderDisabled(provider: String) { actualizarEstadoGps() }
    }

    private val vigilante = object : Runnable {
        override fun run() {
            actualizarEstadoGps()
            main.postDelayed(this, 2000)
        }
    }

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidGraphicFactory.createInstance(application)
        cursorEstilo = getSharedPreferences("mapa", MODE_PRIVATE).getInt("cursor", 1)
        construirPantalla()
        iniciarVoz()
        MapStore.cleanParts(this)
        val guardados = MapStore.installed(this)
        val ultimo = getSharedPreferences("mapa", MODE_PRIVATE).getString("actual", null)
        val elegido = guardados.firstOrNull { it.name == ultimo } ?: guardados.firstOrNull()
        if (elegido != null) abrirMapa(elegido) else mostrarEstado(Estado.SIN_MAPA)
    }

    override fun onStart() {
        super.onStart()
        pedirPermisoYEmpezar()
        main.post(vigilante)
    }

    override fun onStop() {
        super.onStop()
        detenerGps()
        main.removeCallbacks(vigilante)
    }

    override fun onDestroy() {
        bajada?.cancelar()
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) { }
        quitarMapa()
        try { mapView.destroyAll() } catch (e: Exception) { }
        AndroidGraphicFactory.clearResourceMemoryCache()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ pantalla

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun fondo(color: Int, radio: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radio).toFloat()
        }

    private fun texto(t: String, tam: Float, color: Int = Color.WHITE, negrita: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = tam
            setTextColor(color)
            if (negrita) setTypeface(typeface, Typeface.BOLD)
        }

    private fun boton(t: String, principal: Boolean, accion: () -> Unit): Button =
        Button(this).apply {
            text = t
            isAllCaps = false
            textSize = 16f
            setTextColor(if (principal) Color.WHITE else 0xFF0B3D5C.toInt())
            background = fondo(if (principal) 0xFF1976D2.toInt() else 0xFFE3EEF7.toInt(), 14)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { accion() }
        }

    private fun botonRedondo(t: String, accion: () -> Unit): TextView =
        texto(t, 24f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = fondo(0xE60B3D5C.toInt(), 28)
            setOnClickListener { accion() }
        }

    private fun construirPantalla() {
        val raiz = FrameLayout(this)
        raiz.fitsSystemWindows = true

        mapView = MapView(this)
        mapView.isClickable = true
        mapView.mapScaleBar.isVisible = true
        mapView.model.mapViewPosition.setZoomLevelMin(8.toByte())
        mapView.model.mapViewPosition.setZoomLevelMax(20.toByte())
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onLongPress(e: MotionEvent) { alMantener(e.x, e.y) }
        })
        mapView.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_MOVE) seguir = false
            detector.onTouchEvent(ev)
            false
        }
        raiz.addView(mapView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // barra de arriba: estado del GPS, acceso a los mapas y buscador
        arriba = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = fondo(0xE60B3D5C.toInt(), 16)
            setPadding(dp(14), dp(8), dp(8), dp(8))
        }
        val fila1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        estado = texto("Iniciando…", 15f)
        fila1.addView(estado, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fila1.addView(
            boton("Mapas", false) { mostrarMapas() }.apply { textSize = 14f },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        arriba.addView(fila1)

        val fila2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        campo = EditText(this).apply {
            hint = "Buscar dirección o lugar"
            setHintTextColor(0xFF7A8A99.toInt())
            setTextColor(0xFF14283A.toInt())
            textSize = 16f
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = fondo(Color.WHITE, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnEditorActionListener { _, accion, _ ->
                if (accion == EditorInfo.IME_ACTION_SEARCH) {
                    buscar()
                    true
                } else {
                    false
                }
            }
        }
        fila2.addView(campo, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fila2.addView(
            boton("Buscar", true) { buscar() }.apply { textSize = 14f },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) }
        )
        arriba.addView(
            fila2,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
                rightMargin = dp(6)
            }
        )

        barraPines = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }
        textoPines = texto("", 15f, Color.WHITE, true)
        barraPines.addView(textoPines, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        barraPines.addView(
            boton("Lista", false) { alternarListaPines() }.apply { textSize = 13f; setPadding(dp(12), dp(6), dp(12), dp(6)) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6) }
        )
        barraPines.addView(
            boton("Cerrar", false) { quitarPines() }.apply { textSize = 13f; setPadding(dp(12), dp(6), dp(12), dp(6)) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6) }
        )
        arriba.addView(
            barraPines,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(6)
                rightMargin = dp(6)
            }
        )

        scrollResultados = object : ScrollView(this) {
            override fun onMeasure(anchoSpec: Int, altoSpec: Int) {
                super.onMeasure(anchoSpec, View.MeasureSpec.makeMeasureSpec(dp(300), View.MeasureSpec.AT_MOST))
            }
        }
        scrollResultados.visibility = View.GONE
        listaResultados = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scrollResultados.addView(listaResultados)
        arriba.addView(
            scrollResultados,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(6)
                rightMargin = dp(6)
            }
        )
        raiz.addView(
            arriba,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(10), dp(10), dp(10), 0)
            }
        )

        // botones a la derecha: acercar, alejar, centrar
        botones = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val lado = dp(56)
        fun lp() = LinearLayout.LayoutParams(lado, lado).apply { topMargin = dp(10) }
        botones.addView(botonRedondo("+") { mapView.model.mapViewPosition.zoomIn() }, lp())
        botones.addView(botonRedondo("−") { mapView.model.mapViewPosition.zoomOut() }, lp())
        botones.addView(botonRedondo("◎") { centrarEnMi() }, lp())
        botones.addView(botonRedondo("▲") { mostrarCursores() }, lp())
        raiz.addView(
            botones,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.BOTTOM).apply {
                setMargins(0, 0, dp(12), dp(36))
            }
        )

        // atribución obligatoria de OpenStreetMap
        raiz.addView(
            texto("© OpenStreetMap", 11f, 0xFF333333.toInt()).apply {
                setPadding(dp(6), dp(2), dp(6), dp(2))
                background = fondo(0xB3FFFFFF.toInt(), 6)
            },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.BOTTOM).apply {
                setMargins(dp(8), 0, 0, dp(8))
            }
        )

        // panel de abajo: sin mapa / descargando
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = fondo(0xF20B3D5C.toInt(), 20)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            visibility = View.GONE
        }
        raiz.addView(
            panel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
                setMargins(dp(10), 0, dp(10), dp(10))
            }
        )

        // cartel de arriba durante la navegación: flecha, distancia e indicación
        bannerNav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = fondo(0xF20B3D5C.toInt(), 16)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            visibility = View.GONE
        }
        flechaNav = texto("↑", 44f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            minWidth = dp(64)
        }
        distNav = texto("", 26f, Color.WHITE, true)
        textoNav = texto("", 17f, 0xFFCFE3F2.toInt())
        val columna = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        columna.addView(distNav)
        columna.addView(textoNav)
        bannerNav.addView(flechaNav, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        bannerNav.addView(columna, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        raiz.addView(
            bannerNav,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(10), dp(10), dp(10), 0)
            }
        )

        // panel de abajo para la ruta: vista previa y navegación
        panelRuta = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = fondo(0xF20B3D5C.toInt(), 20)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            visibility = View.GONE
        }
        raiz.addView(
            panelRuta,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
                setMargins(dp(10), 0, dp(10), dp(32))
            }
        )

        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        setContentView(raiz)
    }

    private fun mostrarEstado(e: Estado) {
        estadoApp = e
        botones.visibility = if (e == Estado.LISTO) View.VISIBLE else View.GONE
        panel.removeAllViews()
        barra = null
        textoProgreso = null
        tituloBajada = null
        if (e != Estado.LISTO) {
            panelRuta.visibility = View.GONE
            acomodarBotones()
        }
        if (e == Estado.LISTO) {
            panel.visibility = View.GONE
            return
        }
        panel.visibility = View.VISIBLE
        val reg = Config.REGIONES.first()
        if (e == Estado.SIN_MAPA) {
            panel.addView(texto("Todavía no tenés ningún mapa", 20f, Color.WHITE, true))
            panel.addView(
                texto(
                    "Bajá el mapa con internet una sola vez. Después se usa sin conexión, incluso en modo avión.",
                    15f, 0xFFCFE3F2.toInt()
                ).apply { setPadding(0, dp(6), 0, dp(12)) }
            )
            mensajeError?.let {
                panel.addView(texto(it, 15f, 0xFFFFB4A8.toInt(), true).apply { setPadding(0, 0, 0, dp(12)) })
            }
            panel.addView(boton("Bajar ${reg.nombre}", true) { empezarDescarga(reg) })
            panel.addView(
                boton("Elegir un archivo .map del teléfono", false) { elegirArchivo() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
            )
        } else {
            val tb = texto("Bajando el mapa…", 20f, Color.WHITE, true)
            panel.addView(tb)
            tituloBajada = tb
            val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000; isIndeterminate = true }
            panel.addView(pb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)).apply { topMargin = dp(12) })
            val tp = texto("Conectando…", 15f, 0xFFCFE3F2.toInt())
            panel.addView(tp, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
            panel.addView(
                boton("Cancelar", false) { bajada?.cancelar() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) }
            )
            barra = pb
            textoProgreso = tp
        }
    }

    // ------------------------------------------------------------------ mapas

    private fun abrirMapa(archivo: File): Boolean {
        return try {
            val datos = MapFile(archivo)
            quitarMapa()
            limpiarRuta()
            val cache = AndroidUtil.createTileCache(
                this, "tiles-" + archivo.nameWithoutExtension,
                mapView.model.displayModel.tileSize, 1f, mapView.model.frameBufferModel.overdrawFactor
            )
            val capa = TileRendererLayer(cache, datos, mapView.model.mapViewPosition, AndroidGraphicFactory.INSTANCE)
            capa.setXmlRenderTheme(InternalRenderTheme.DEFAULT)
            mapView.layerManager.layers.add(0, capa)
            tileCache = cache
            capaMapa = capa
            mapaActual = archivo
            getSharedPreferences("mapa", MODE_PRIVATE).edit().putString("actual", archivo.name).apply()

            val caja = datos.boundingBox()
            val yo = ubicacion
            if (yo != null && caja.contains(LatLong(yo.latitude, yo.longitude))) {
                mapView.setCenter(LatLong(yo.latitude, yo.longitude))
                mapView.setZoomLevel(16.toByte())
            } else {
                mapView.setCenter(caja.centerPoint)
                mapView.setZoomLevel(12.toByte())
            }
            mensajeError = null
            mostrarEstado(Estado.LISTO)
            ubicacion?.let { ponerMarcador(it) }
            cargarNav()
            true
        } catch (e: Throwable) {
            mensajeError = "No se pudo abrir el mapa: ${e.message ?: "archivo dañado"}."
            mostrarEstado(Estado.SIN_MAPA)
            false
        }
    }

    private fun quitarMapa() {
        capaMapa?.let {
            try { mapView.layerManager.layers.remove(it) } catch (e: Exception) { }
            try { it.onDestroy() } catch (e: Exception) { }
        }
        capaMapa = null
        try { tileCache?.destroy() } catch (e: Exception) { }
        tileCache = null
        mapaActual = null
    }

    private fun empezarDescarga(region: Region) {
        if (bajada != null) return
        mensajeError = null
        mostrarEstado(Estado.BAJANDO)
        val d = Downloader(applicationContext, { hecho, total -> mostrarProgreso(hecho, total) }, { res, archivo -> terminarTarea(res, archivo) })
        d.alCambiarEtapa = { t -> tituloBajada?.text = t }
        bajada = d
        d.bajar(region)
    }

    private fun empezarDescargaRutas(region: Region) {
        if (bajada != null) return
        mensajeError = null
        bajandoRutas = true
        mostrarEstado(Estado.BAJANDO)
        val d = Downloader(applicationContext, { hecho, total -> mostrarProgreso(hecho, total) }, { res, archivo -> terminarTarea(res, archivo) })
        d.alCambiarEtapa = { t -> tituloBajada?.text = t }
        bajada = d
        d.bajarRutas(region)
    }

    private fun elegirArchivo() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, PEDIDO_ARCHIVO)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PEDIDO_ARCHIVO || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (bajada != null) return
        mensajeError = null
        mostrarEstado(Estado.BAJANDO)
        val d = Downloader(applicationContext, { hecho, total -> mostrarProgreso(hecho, total) }, { res, archivo -> terminarTarea(res, archivo) })
        bajada = d
        d.importar(uri)
    }

    private fun mostrarProgreso(hecho: Long, total: Long) {
        val pb = barra ?: return
        val tp = textoProgreso ?: return
        if (total > 0) {
            pb.isIndeterminate = false
            pb.progress = ((hecho * 1000) / total).toInt()
            tp.text = "${hecho / 1048576} de ${total / 1048576} MB"
        } else {
            tp.text = "${hecho / 1048576} MB"
        }
    }

    private fun terminarTarea(res: Resultado, archivo: File?) {
        bajada = null
        val soloRutas = bajandoRutas
        bajandoRutas = false
        when (res) {
            is Resultado.Ok, is Resultado.Parcial -> {
                if (soloRutas) {
                    mostrarEstado(if (mapaActual != null) Estado.LISTO else Estado.SIN_MAPA)
                    cargarNav()
                    Toast.makeText(this, "Rutas y buscador listos", Toast.LENGTH_SHORT).show()
                    return
                }
                val aviso = (res as? Resultado.Parcial)?.mensaje
                if (archivo != null && abrirMapa(archivo)) {
                    if (aviso != null) {
                        AlertDialog.Builder(this).setTitle("Mapa listo").setMessage(aviso).setPositiveButton("Entendido", null).show()
                    }
                    return
                }
                if (mapaActual == null) mostrarEstado(Estado.SIN_MAPA)
            }
            is Resultado.Cancelado -> {
                mensajeError = null
                mostrarEstado(if (mapaActual != null) Estado.LISTO else Estado.SIN_MAPA)
            }
            is Resultado.Error -> {
                mensajeError = res.mensaje
                mostrarEstado(if (mapaActual != null) Estado.LISTO else Estado.SIN_MAPA)
                if (mapaActual != null) {
                    estado.text = res.mensaje
                    AlertDialog.Builder(this).setTitle("No se pudo").setMessage(res.mensaje).setPositiveButton("Entendido", null).show()
                }
            }
        }
    }

    private fun mostrarMapas() {
        val caja = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(4))
        }
        val lista = MapStore.installed(this)
        if (lista.isEmpty()) {
            caja.addView(texto("No hay mapas instalados.", 16f, 0xFF222222.toInt()))
        }
        var dialogo: AlertDialog? = null
        for (f in lista) {
            val fila = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val activo = f == mapaActual
            fila.addView(texto(MapStore.niceName(f) + if (activo) "  (en uso)" else "", 16f, 0xFF0B3D5C.toInt(), true))
            fila.addView(texto(MapStore.sizeText(f), 13f, 0xFF555555.toInt()))
            val acciones = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            if (!activo) {
                acciones.addView(boton("Usar", true) { dialogo?.dismiss(); abrirMapa(f) })
            }
            acciones.addView(
                boton("Eliminar", false) {
                    dialogo?.dismiss()
                    confirmarBorrado(f)
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) }
            )
            fila.addView(acciones, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
            caja.addView(fila)
        }
        val mapaId = mapaActual?.nameWithoutExtension
        val regActual = Config.REGIONES.firstOrNull { it.id == mapaId }
        if (mapaId != null) {
            val hayNav = MapStore.navFile(this, mapaId).exists()
            caja.addView(texto("Rutas y buscador", 16f, 0xFF0B3D5C.toInt(), true).apply { setPadding(0, dp(14), 0, 0) })
            caja.addView(
                texto(
                    if (navKit != null) "Listos: podés buscar direcciones y trazar rutas sin conexión."
                    else if (hayNav) "Cargando…"
                    else if (regActual != null) "Todavía no los bajaste."
                    else "Este mapa no tiene datos de rutas.",
                    13f, 0xFF555555.toInt()
                )
            )
            if (regActual != null) {
                caja.addView(
                    boton(if (hayNav) "Actualizar rutas y buscador" else "Bajar rutas y buscador", !hayNav) {
                        dialogo?.dismiss()
                        empezarDescargaRutas(regActual)
                    },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
                )
            }
        }
        val reg = Config.REGIONES.first()
        caja.addView(
            boton("Bajar o actualizar ${reg.nombre}", true) { dialogo?.dismiss(); empezarDescarga(reg) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) }
        )
        caja.addView(
            boton("Elegir un archivo .map", false) { dialogo?.dismiss(); elegirArchivo() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
        )
        caja.addView(texto("Datos de mapa y rutas: © colaboradores de OpenStreetMap (licencia ODbL).", 12f, 0xFF555555.toInt()).apply { setPadding(0, dp(12), 0, 0) })
        val scroll = ScrollView(this).apply { addView(caja) }
        val d = AlertDialog.Builder(this).setTitle("Mapas sin conexión").setView(scroll).setNegativeButton("Cerrar", null).create()
        dialogo = d
        d.show()
    }

    private fun confirmarBorrado(f: File) {
        AlertDialog.Builder(this)
            .setTitle("¿Eliminar este mapa?")
            .setMessage("${MapStore.niceName(f)} (${MapStore.sizeText(f)}). Para volver a usarlo hay que bajarlo de nuevo.")
            .setPositiveButton("Eliminar") { _, _ ->
                val eraElActual = f == mapaActual
                if (eraElActual) { quitarMapa(); limpiarRuta(); navKit = null }
                f.delete()
                MapStore.navFile(this, f.nameWithoutExtension).delete()
                if (eraElActual) {
                    val otro = MapStore.installed(this).firstOrNull()
                    if (otro != null) abrirMapa(otro) else mostrarEstado(Estado.SIN_MAPA)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ------------------------------------------------------------------ GPS

    private fun tienePermiso(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun pedirPermisoYEmpezar() {
        if (tienePermiso()) {
            empezarGps()
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), PEDIDO_UBICACION)
            actualizarEstadoGps()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PEDIDO_UBICACION) {
            if (tienePermiso()) empezarGps() else actualizarEstadoGps()
        }
    }

    private fun empezarGps() {
        if (gpsActivo || !tienePermiso()) return
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, oyente)
                gpsActivo = true
            }
            val ultima = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (ultima != null && ubicacion == null) alRecibirUbicacion(ultima, false)
        } catch (e: SecurityException) {
            // sin permiso: se avisa en la barra de estado
        }
        actualizarEstadoGps()
    }

    private fun detenerGps() {
        try { lm.removeUpdates(oyente) } catch (e: Exception) { }
        gpsActivo = false
    }

    private fun alRecibirUbicacion(l: Location, fresca: Boolean = true) {
        ubicacion = l
        if (fresca) ultimaFijacion = System.currentTimeMillis()
        ponerMarcador(l)
        if (navegando) avanzarNavegacion(l)
        if (seguir && capaMapa != null) mapView.setCenter(LatLong(l.latitude, l.longitude))
        actualizarEstadoGps()
    }

    private fun ponerMarcador(l: Location) {
        if (capaMapa == null) return
        if (l.hasBearing() && l.hasSpeed() && l.speed > 1f) rumboCursor = l.bearing
        val pos = LatLong(l.latitude, l.longitude)
        val m = marcador
        val cambio = estiloDibujado != cursorEstilo ||
            (cursorEstilo != 0 && diferenciaAngulo(rumboCursor, rumboDibujado) >= 8f)
        if (m == null || cambio) {
            if (m != null) {
                try { mapView.layerManager.layers.remove(m) } catch (e: Exception) { }
            }
            val nuevo = Marker(pos, cursorBitmap(), 0, 0)
            mapView.layerManager.layers.add(nuevo)
            marcador = nuevo
            estiloDibujado = cursorEstilo
            rumboDibujado = rumboCursor
        } else {
            m.latLong = pos
            m.requestRedraw()
        }
    }

    private fun diferenciaAngulo(a: Float, b: Float): Float {
        var d = Math.abs(a - b) % 360f
        if (d > 180f) d = 360f - d
        return d
    }

    private fun cursorBitmap(): org.mapsforge.core.graphics.Bitmap =
        AndroidGraphicFactory.convertToBitmap(BitmapDrawable(resources, dibujarCursor(cursorEstilo, rumboCursor, dp(48))))

    /** Dibuja el cursor visto desde arriba, apuntando hacia "rumbo" grados (0 = norte). */
    private fun dibujarCursor(estilo: Int, rumbo: Float, tam: Int): android.graphics.Bitmap {
        val bmp = android.graphics.Bitmap.createBitmap(tam, tam, android.graphics.Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val azul = 0xFF1976D2.toInt()
        val oscuro = 0xFF14283A.toInt()
        val relleno = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = azul }
        val borde = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 0.09f; strokeJoin = Paint.Join.ROUND }
        val negro = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = oscuro }
        val cx = tam / 2f
        val cy = tam / 2f
        if (estilo == 0) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = Color.WHITE
            c.drawCircle(cx, cy, tam * 0.30f, p)
            p.color = azul
            c.drawCircle(cx, cy, tam * 0.22f, p)
            return bmp
        }
        val u = tam * 0.7f
        c.save()
        c.translate(cx, cy)
        c.rotate(rumbo)
        c.scale(u, u)
        fun caja(x1: Float, y1: Float, x2: Float, y2: Float, radio: Float, color: Int, conBorde: Boolean) {
            val r = RectF(x1, y1, x2, y2)
            if (conBorde) c.drawRoundRect(r, radio, radio, borde)
            val pr = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = color }
            c.drawRoundRect(r, radio, radio, pr)
        }
        when (estilo) {
            1 -> {
                val f = Path().apply {
                    moveTo(0f, -0.5f); lineTo(0.38f, 0.46f); lineTo(0f, 0.22f); lineTo(-0.38f, 0.46f); close()
                }
                c.drawPath(f, borde)
                c.drawPath(f, relleno)
            }
            2 -> {
                caja(-0.06f, -0.5f, 0.06f, -0.2f, 0.05f, oscuro, false)
                caja(-0.07f, 0.18f, 0.07f, 0.5f, 0.05f, oscuro, false)
                caja(-0.09f, -0.32f, 0.09f, 0.3f, 0.08f, azul, true)
                val manubrioB = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 0.13f; strokeCap = Paint.Cap.ROUND }
                val manubrio = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = oscuro; strokeWidth = 0.07f; strokeCap = Paint.Cap.ROUND }
                c.drawLine(-0.34f, -0.26f, 0.34f, -0.26f, manubrioB)
                c.drawLine(-0.34f, -0.26f, 0.34f, -0.26f, manubrio)
                caja(-0.2f, -0.2f, 0.2f, 0.06f, 0.1f, 0xFF64B5F6.toInt(), true)
                val casco = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xFFFFC107.toInt() }
                c.drawCircle(0f, -0.04f, 0.11f, casco)
            }
            3 -> {
                caja(-0.28f, -0.34f, -0.19f, -0.13f, 0.03f, oscuro, false)
                caja(0.19f, -0.34f, 0.28f, -0.13f, 0.03f, oscuro, false)
                caja(-0.28f, 0.15f, -0.19f, 0.36f, 0.03f, oscuro, false)
                caja(0.19f, 0.15f, 0.28f, 0.36f, 0.03f, oscuro, false)
                caja(-0.22f, -0.47f, 0.22f, 0.47f, 0.13f, azul, true)
                caja(-0.16f, -0.24f, 0.16f, -0.07f, 0.04f, 0xFFB3E5FC.toInt(), false)
                caja(-0.16f, -0.04f, 0.16f, 0.17f, 0.04f, 0xFF0D47A1.toInt(), false)
                caja(-0.15f, 0.2f, 0.15f, 0.31f, 0.04f, 0xFFB3E5FC.toInt(), false)
            }
            else -> {
                caja(-0.28f, -0.38f, -0.19f, -0.17f, 0.03f, oscuro, false)
                caja(0.19f, -0.38f, 0.28f, -0.17f, 0.03f, oscuro, false)
                caja(-0.28f, 0.2f, -0.19f, 0.41f, 0.03f, oscuro, false)
                caja(0.19f, 0.2f, 0.28f, 0.41f, 0.03f, oscuro, false)
                caja(-0.22f, -0.5f, 0.22f, 0.5f, 0.08f, azul, true)
                caja(-0.18f, -0.43f, 0.18f, -0.04f, 0.05f, 0xFF0D47A1.toInt(), false)
                caja(-0.14f, -0.38f, 0.14f, -0.24f, 0.03f, 0xFFB3E5FC.toInt(), false)
                caja(-0.17f, 0.02f, 0.17f, 0.45f, 0.03f, 0xFF455A64.toInt(), false)
            }
        }
        c.restore()
        return bmp
    }

    private fun mostrarCursores() {
        val caja = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(4))
        }
        var dialogo: AlertDialog? = null
        estilos.forEachIndexed { i, nombre ->
            val fila = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(8), dp(8), dp(8))
                background = fondo(if (i == cursorEstilo) 0xFFD6E6F3.toInt() else Color.TRANSPARENT, 12)
            }
            val img = ImageView(this).apply {
                setImageBitmap(dibujarCursor(i, 0f, dp(56)))
                background = fondo(0xFF8FA3B3.toInt(), 12)
            }
            fila.addView(img, LinearLayout.LayoutParams(dp(56), dp(56)))
            fila.addView(
                texto(nombre + if (i == cursorEstilo) "  ✓" else "", 18f, 0xFF0B3D5C.toInt(), true).apply { setPadding(dp(14), 0, 0, 0) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            fila.setOnClickListener {
                elegirCursor(i)
                dialogo?.dismiss()
            }
            caja.addView(fila, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) })
        }
        val scroll = ScrollView(this).apply { addView(caja) }
        val d = AlertDialog.Builder(this).setTitle("Elegí tu cursor").setView(scroll).setNegativeButton("Cerrar", null).create()
        dialogo = d
        d.show()
    }

    private fun elegirCursor(i: Int) {
        cursorEstilo = i
        getSharedPreferences("mapa", MODE_PRIVATE).edit().putInt("cursor", i).apply()
        ubicacion?.let { ponerMarcador(it) }
    }

    private fun centrarEnMi() {
        val l = ubicacion
        if (l == null) {
            estado.text = "Todavía no hay ubicación. Salí a un lugar abierto."
            return
        }
        seguir = true
        mapView.setCenter(LatLong(l.latitude, l.longitude))
        if (mapView.model.mapViewPosition.zoomLevel < 15) mapView.setZoomLevel(16.toByte())
    }

    private fun rumbo(grados: Float): String {
        val n = arrayOf("N", "NE", "E", "SE", "S", "SO", "O", "NO")
        return n[(((grados + 22.5f) % 360f) / 45f).toInt().coerceIn(0, 7)]
    }

    private fun actualizarEstadoGps() {
        if (bajada != null) return
        if (!tienePermiso()) {
            estado.text = "Falta el permiso de ubicación"
            return
        }
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            estado.text = "El GPS está apagado. Activalo en los ajustes."
            return
        }
        if (!gpsActivo) empezarGps()
        val l = ubicacion
        val hace = System.currentTimeMillis() - ultimaFijacion
        if (l == null || ultimaFijacion == 0L) {
            estado.text = "Buscando señal GPS…"
        } else if (hace > 8000) {
            estado.text = "Señal GPS perdida, buscando…"
        } else {
            var t = "GPS ±${l.accuracy.toInt()} m"
            if (l.hasSpeed()) t += " · ${(l.speed * 3.6f).toInt()} km/h"
            if (l.hasBearing() && l.hasSpeed() && l.speed > 1f) t += " · ${rumbo(l.bearing)}"
            estado.text = t
        }
    }

    // ------------------------------------------------------------------ rutas y buscador

    private fun referencia(): LatLong {
        val l = ubicacion
        if (l != null) return LatLong(l.latitude, l.longitude)
        return mapView.model.mapViewPosition.center
    }

    /** Carga en segundo plano las calles y el buscador del mapa en uso. */
    private fun cargarNav() {
        navKit = null
        val mapa = mapaActual
        if (mapa == null) {
            actualizarAvisoBuscador()
            return
        }
        val f = MapStore.navFile(this, mapa.nameWithoutExtension)
        if (!f.exists() || cargandoNav) {
            actualizarAvisoBuscador()
            return
        }
        cargandoNav = true
        actualizarAvisoBuscador()
        Thread {
            var kit: NavKit? = null
            var error = ""
            try {
                val datos = NavData.cargar(f)
                kit = NavKit(datos, Router(datos), Searcher(datos))
            } catch (e: Throwable) {
                error = e.message ?: "error"
            }
            main.post {
                cargandoNav = false
                navKit = kit
                if (kit == null) {
                    Toast.makeText(this, "No se pudieron cargar las rutas: $error", Toast.LENGTH_LONG).show()
                }
                actualizarAvisoBuscador()
            }
        }.start()
    }

    private fun actualizarAvisoBuscador() {
        campo.hint = when {
            navKit != null -> "Buscar dirección o lugar"
            cargandoNav -> "Cargando el buscador…"
            else -> "Buscar (primero hay que bajar las rutas)"
        }
    }

    private fun ocultarTeclado() {
        try {
            val im = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            im.hideSoftInputFromWindow(campo.windowToken, 0)
            campo.clearFocus()
        } catch (e: Exception) {
        }
    }

    private fun ofrecerBajarRutas() {
        val id = mapaActual?.nameWithoutExtension
        val reg = Config.REGIONES.firstOrNull { it.id == id }
        if (reg == null) {
            AlertDialog.Builder(this)
                .setTitle("Sin rutas para este mapa")
                .setMessage("Este mapa no tiene datos de rutas y buscador. Usá el mapa de Buenos Aires desde el botón Mapas.")
                .setPositiveButton("Entendido", null)
                .show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Rutas y buscador")
            .setMessage("Para buscar direcciones y trazar rutas sin conexión hay que bajar los datos de las calles. Se bajan una sola vez, con internet.")
            .setPositiveButton("Bajar ahora") { _, _ -> empezarDescargaRutas(reg) }
            .setNegativeButton("Ahora no", null)
            .show()
    }

    // ------------------------------------------------------------------ búsqueda

    private fun buscar() {
        val q = campo.text.toString().trim()
        if (q.isEmpty()) return
        ocultarTeclado()
        if (capaMapa == null) {
            Toast.makeText(this, "Primero hace falta un mapa.", Toast.LENGTH_SHORT).show()
            return
        }
        val kit = navKit
        if (kit == null) {
            if (cargandoNav) {
                Toast.makeText(this, "Cargando el buscador, probá en unos segundos.", Toast.LENGTH_SHORT).show()
            } else {
                ofrecerBajarRutas()
            }
            return
        }
        mostrarResultadosTexto("Buscando…")
        val ref = referencia()
        Thread {
            val res: List<Searcher.Lugar> = try {
                kit.buscador.buscar(q, 80, ref.latitude, ref.longitude)
            } catch (e: Throwable) {
                emptyList()
            }
            main.post { mostrarResultados(res) }
        }.start()
    }

    private fun mostrarResultadosTexto(t: String) {
        listaResultados.removeAllViews()
        listaResultados.addView(texto(t, 15f, 0xFFCFE3F2.toInt()).apply { setPadding(dp(8), dp(8), dp(8), dp(8)) })
        scrollResultados.visibility = View.VISIBLE
    }

    private fun mostrarResultados(todos: List<Searcher.Lugar>) {
        quitarPines()
        val lugares = todos.filter { it.tipo == Searcher.LUGAR }.sortedBy { it.distancia }
        if (lugares.size >= 2) {
            mostrarPines(lugares)
            return
        }
        val res = todos.take(12)
        if (res.isEmpty()) {
            mostrarResultadosTexto("No encontré nada. Probá con otra escritura, por ejemplo \"Rivadavia 7000\" o \"Medrano y Rivadavia\".")
            return
        }
        listaResultados.removeAllViews()
        for (l in res) {
            val fila = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = fondo(0x26FFFFFF, 10)
            }
            fila.addView(texto(l.titulo, 16f, Color.WHITE, true))
            fila.addView(texto(l.detalle + " · " + Formato.distancia(l.distancia), 13f, 0xFFCFE3F2.toInt()))
            fila.setOnClickListener { elegirDestino(l.titulo, l.lat, l.lon) }
            listaResultados.addView(
                fila,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4) }
            )
        }
        scrollResultados.visibility = View.VISIBLE
    }

    // ------------------------------------------------------------------ pines de la búsqueda

    private fun mostrarPines(lugares: List<Searcher.Lugar>) {
        val usados = lugares.take(40)
        lugaresPines = usados
        val bmp = dibujarPin(0xFFEF6C00.toInt())
        val icono = AndroidGraphicFactory.convertToBitmap(BitmapDrawable(resources, bmp))
        for (l in usados) {
            val lugar = l
            val m = object : Marker(LatLong(lugar.lat, lugar.lon), icono, 0, -bmp.height / 2) {
                override fun onTap(tapLatLong: LatLong, layerXY: Point, tapXY: Point): Boolean {
                    if (contains(layerXY, tapXY)) {
                        main.post { preguntarIr(lugar) }
                        return true
                    }
                    return false
                }
            }
            mapView.layerManager.layers.add(m)
            pines.add(m)
        }
        refrescarCursorArriba()
        ajustarVista(usados)
        val extra = if (lugares.size > usados.size) " (los 40 más cercanos)" else ""
        textoPines.text = "${usados.size} lugares$extra · tocá un pin"
        barraPines.visibility = View.VISIBLE
        scrollResultados.visibility = View.GONE
    }

    private fun preguntarIr(l: Searcher.Lugar) {
        android.app.AlertDialog.Builder(this)
            .setTitle(l.titulo)
            .setMessage(l.detalle + " · a " + Formato.distancia(l.distancia))
            .setPositiveButton("Ir") { _, _ -> elegirDestino(l.titulo, l.lat, l.lon) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun alternarListaPines() {
        if (scrollResultados.visibility == View.VISIBLE) {
            scrollResultados.visibility = View.GONE
            return
        }
        listaResultados.removeAllViews()
        for (l in lugaresPines) {
            val fila = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = fondo(0x26FFFFFF, 10)
            }
            fila.addView(texto(l.titulo, 16f, Color.WHITE, true))
            fila.addView(texto(l.detalle + " · " + Formato.distancia(l.distancia), 13f, 0xFFCFE3F2.toInt()))
            fila.setOnClickListener { elegirDestino(l.titulo, l.lat, l.lon) }
            listaResultados.addView(
                fila,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4) }
            )
        }
        scrollResultados.visibility = View.VISIBLE
    }

    private fun quitarPines() {
        for (m in pines) {
            try { mapView.layerManager.layers.remove(m) } catch (e: Exception) { }
        }
        pines.clear()
        lugaresPines = emptyList()
        barraPines.visibility = View.GONE
    }

    /** Centra y aleja el mapa lo justo para que entren todos los pines. */
    private fun ajustarVista(lugares: List<Searcher.Lugar>) {
        var minLat = lugares[0].lat
        var maxLat = minLat
        var minLon = lugares[0].lon
        var maxLon = minLon
        for (l in lugares) {
            if (l.lat < minLat) minLat = l.lat
            if (l.lat > maxLat) maxLat = l.lat
            if (l.lon < minLon) minLon = l.lon
            if (l.lon > maxLon) maxLon = l.lon
        }
        val spanLat = (maxLat - minLat) * 1.3 + 0.0006
        val spanLon = (maxLon - minLon) * 1.3 + 0.0006
        val cLat = (minLat + maxLat) / 2
        val cLon = (minLon + maxLon) / 2
        val ancho = mapView.width.toDouble()
        val alto = mapView.height.toDouble()
        val tile = mapView.model.displayModel.tileSize.toDouble()
        var z = 13
        if (ancho > 0 && alto > 0) {
            val cosLat = Math.cos(Math.toRadians(cLat))
            z = 8
            for (cand in 17 downTo 8) {
                val mundo = tile * Math.pow(2.0, cand.toDouble())
                val pw = spanLon / 360.0 * mundo
                val ph = spanLat / 360.0 * mundo / cosLat
                if (pw <= ancho * 0.9 && ph <= alto * 0.5) {
                    z = cand
                    break
                }
            }
        }
        seguir = false
        mapView.setCenter(LatLong(cLat, cLon))
        mapView.setZoomLevel(z.toByte())
    }

    private fun ocultarResultados() {
        scrollResultados.visibility = View.GONE
    }

    // ------------------------------------------------------------------ destino y ruta

    /** Toque largo sobre el mapa: ese punto pasa a ser el destino. */
    private fun alMantener(x: Float, y: Float) {
        if (capaMapa == null || navegando) return
        val p = mapView.mapViewProjection.fromPixels(x.toDouble(), y.toDouble()) ?: return
        val kit = navKit
        if (kit == null) {
            if (!cargandoNav) ofrecerBajarRutas()
            return
        }
        var nombre = "Punto elegido en el mapa"
        try {
            val s = kit.datos.ubicar(p.latitude, p.longitude, 60.0)
            if (s != null) {
                val n = kit.datos.lName[s.tramo]
                if (n >= 0) nombre = "Cerca de " + kit.datos.names[n]
            }
        } catch (e: Throwable) {
        }
        elegirDestino(nombre, p.latitude, p.longitude)
    }

    private fun elegirDestino(titulo: String, lat: Double, lon: Double) {
        quitarPines()
        ocultarResultados()
        ocultarTeclado()
        destLat = lat
        destLon = lon
        destTitulo = titulo
        hayDestino = true
        ponerDestino(lat, lon)
        seguir = false
        mapView.setCenter(LatLong(lat, lon))
        if (mapView.model.mapViewPosition.zoomLevel < 15) mapView.setZoomLevel(15.toByte())
        calcularRuta(false)
    }

    private fun dibujarPin(colorPin: Int = 0xFFD32F2F.toInt()): android.graphics.Bitmap {
        val w = dp(34)
        val h = dp(46)
        val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rojo = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = colorPin }
        val blanco = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
        val punta = Path().apply {
            moveTo(w * 0.16f, w * 0.66f)
            lineTo(w * 0.84f, w * 0.66f)
            lineTo(w / 2f, h.toFloat())
            close()
        }
        c.drawPath(punta, rojo)
        c.drawCircle(w / 2f, w / 2f, w * 0.46f, rojo)
        c.drawCircle(w / 2f, w / 2f, w * 0.18f, blanco)
        return bmp
    }

    private fun ponerDestino(lat: Double, lon: Double) {
        quitarDestino()
        val bmp = dibujarPin()
        val m = Marker(LatLong(lat, lon), AndroidGraphicFactory.convertToBitmap(BitmapDrawable(resources, bmp)), 0, -bmp.height / 2)
        mapView.layerManager.layers.add(m)
        capaDestino = m
        refrescarCursorArriba()
    }

    private fun quitarDestino() {
        capaDestino?.let {
            try { mapView.layerManager.layers.remove(it) } catch (e: Exception) { }
        }
        capaDestino = null
    }

    /** Vuelve a poner el cursor encima de la ruta y del destino. */
    private fun refrescarCursorArriba() {
        val m = marcador
        if (m != null) {
            try { mapView.layerManager.layers.remove(m) } catch (e: Exception) { }
            marcador = null
            estiloDibujado = -1
        }
        ubicacion?.let { ponerMarcador(it) }
    }

    private fun dibujarRuta(r: Route) {
        capaRuta?.let {
            try { mapView.layerManager.layers.remove(it) } catch (e: Exception) { }
        }
        val pintura = AndroidGraphicFactory.INSTANCE.createPaint()
        pintura.setColor(0xCC1565C0.toInt())
        pintura.setStrokeWidth(dp(7).toFloat())
        pintura.setStyle(org.mapsforge.core.graphics.Style.STROKE)
        val linea = Polyline(pintura, AndroidGraphicFactory.INSTANCE)
        for (i in 0 until r.puntos()) {
            linea.latLongs.add(LatLong(r.lat[i], r.lon[i]))
        }
        mapView.layerManager.layers.add(linea)
        capaRuta = linea
        refrescarCursorArriba()
    }

    private fun encuadrar(r: Route) {
        var minLat = r.lat[0]
        var maxLat = r.lat[0]
        var minLon = r.lon[0]
        var maxLon = r.lon[0]
        for (i in 0 until r.puntos()) {
            if (r.lat[i] < minLat) minLat = r.lat[i]
            if (r.lat[i] > maxLat) maxLat = r.lat[i]
            if (r.lon[i] < minLon) minLon = r.lon[i]
            if (r.lon[i] > maxLon) maxLon = r.lon[i]
        }
        val ancho = com.mapaoffline.gps.nav.Geo.dist(minLat, minLon, minLat, maxLon)
        val alto = com.mapaoffline.gps.nav.Geo.dist(minLat, minLon, maxLat, minLon)
        val m = Math.max(ancho, alto)
        val zoom = when {
            m < 800 -> 16
            m < 2000 -> 15
            m < 4000 -> 14
            m < 8000 -> 13
            m < 16000 -> 12
            m < 32000 -> 11
            else -> 10
        }
        seguir = false
        mapView.setCenter(LatLong((minLat + maxLat) / 2, (minLon + maxLon) / 2))
        mapView.setZoomLevel(zoom.toByte())
    }

    private fun acomodarBotones() {
        val lp = botones.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = if (panelRuta.visibility == View.VISIBLE) dp(210) else dp(36)
        botones.layoutParams = lp
    }

    private fun limpiarRuta() {
        capaRuta?.let {
            try { mapView.layerManager.layers.remove(it) } catch (e: Exception) { }
        }
        capaRuta = null
        quitarDestino()
        ruta = null
        hayDestino = false
        panelRuta.visibility = View.GONE
        acomodarBotones()
    }

    private fun calcularRuta(reruteo: Boolean) {
        val kit = navKit ?: return
        if (!hayDestino || calculando) return
        val l = ubicacion
        if (l == null) {
            mostrarAvisoRuta("Todavía no hay señal GPS. Salí a un lugar abierto y tocá \"Calcular ruta\" cuando aparezca tu ubicación.")
            return
        }
        calculando = true
        val rumbo = if (l.hasBearing() && l.hasSpeed() && l.speed > 1.5f) l.bearing.toDouble() else -1.0
        val dLat = destLat
        val dLon = destLon
        if (!reruteo) mostrarCalculando()
        Thread {
            var r: Route? = null
            var error = ""
            try {
                r = kit.router.ruta(l.latitude, l.longitude, dLat, dLon, rumbo)
            } catch (e: RutaException) {
                error = e.message ?: "No se pudo calcular la ruta."
            } catch (e: Throwable) {
                error = "No se pudo calcular la ruta."
            }
            main.post { alTerminarRuta(r, error, reruteo) }
        }.start()
    }

    private fun alTerminarRuta(r: Route?, error: String, reruteo: Boolean) {
        calculando = false
        if (!hayDestino) return
        if (r == null) {
            if (reruteo && navegando) {
                hablar("No pude calcular otra ruta")
                textoNav.text = "No pude recalcular. Sigo con la ruta anterior."
            } else {
                mostrarAvisoRuta(error)
            }
            return
        }
        ruta = r
        dibujarRuta(r)
        if (reruteo && navegando) {
            segmentoActual = 0
            anunciados.clear()
            val p = r.pasos[if (r.pasos.size > 1) 1 else 0]
            actualizarBanner(p, p.desde)
            hablar(r.pasos[0].texto())
        } else {
            encuadrar(r)
            mostrarVistaPrevia()
        }
    }

    private fun mostrarCalculando() {
        panelRuta.removeAllViews()
        panelRuta.addView(texto(destTitulo, 18f, Color.WHITE, true))
        panelRuta.addView(texto("Calculando la ruta…", 15f, 0xFFCFE3F2.toInt()).apply { setPadding(0, dp(4), 0, dp(10)) })
        panelRuta.addView(boton("Cancelar", false) { limpiarRuta() })
        panelRuta.visibility = View.VISIBLE
        acomodarBotones()
    }

    private fun mostrarAvisoRuta(mensaje: String) {
        panelRuta.removeAllViews()
        panelRuta.addView(texto(destTitulo, 18f, Color.WHITE, true))
        panelRuta.addView(texto(mensaje, 15f, 0xFFFFD0C8.toInt()).apply { setPadding(0, dp(4), 0, dp(10)) })
        val fila = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fila.addView(boton("Calcular ruta", true) { calcularRuta(false) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fila.addView(
            boton("Cancelar", false) { limpiarRuta() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) }
        )
        panelRuta.addView(fila)
        panelRuta.visibility = View.VISIBLE
        acomodarBotones()
    }

    private fun mostrarVistaPrevia() {
        val r = ruta ?: return
        panelRuta.removeAllViews()
        panelRuta.addView(texto(destTitulo, 18f, Color.WHITE, true))
        panelRuta.addView(
            texto("${Formato.distancia(r.distancia)} · ${Formato.tiempo(r.tiempo)} aprox. (sin tránsito)", 15f, 0xFFCFE3F2.toInt())
                .apply { setPadding(0, dp(4), 0, dp(10)) }
        )
        val fila = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fila.addView(boton("Iniciar", true) { iniciarNavegacion() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fila.addView(
            boton("Cancelar", false) { limpiarRuta() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) }
        )
        panelRuta.addView(fila)
        panelRuta.visibility = View.VISIBLE
        acomodarBotones()
    }

    // ------------------------------------------------------------------ navegación

    private fun iniciarNavegacion() {
        val r = ruta ?: return
        navegando = true
        segmentoActual = 0
        fueraCont = 0
        ultimoReruteo = 0L
        anunciados.clear()
        seguir = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        arriba.visibility = View.GONE
        ocultarResultados()
        bannerNav.visibility = View.VISIBLE
        mapView.setZoomLevel(17.toByte())
        ubicacion?.let { mapView.setCenter(LatLong(it.latitude, it.longitude)) }
        mostrarPanelNavegacion()
        val prox = r.pasos[if (r.pasos.size > 1) 1 else 0]
        actualizarBanner(prox, prox.desde)
        var frase = r.pasos[0].texto()
        if (r.pasos.size > 1) frase += ". " + Formato.avisoLejano(prox, prox.desde)
        hablar(frase)
    }

    private fun mostrarPanelNavegacion() {
        panelRuta.removeAllViews()
        val resumen = texto("", 17f, Color.WHITE, true)
        resumenNav = resumen
        panelRuta.addView(resumen)
        val fila = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fila.addView(boton("Salir", false) { terminarNavegacion(false) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val bv = boton(if (vozActiva) "Voz: sí" else "Voz: no", false) {
            vozActiva = !vozActiva
            botonVoz?.text = if (vozActiva) "Voz: sí" else "Voz: no"
            if (!vozActiva) {
                try { tts?.stop() } catch (e: Exception) { }
            }
        }
        botonVoz = bv
        fila.addView(bv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
        panelRuta.addView(fila, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        panelRuta.visibility = View.VISIBLE
        acomodarBotones()
    }

    private fun actualizarBanner(p: Route.Paso, falta: Double) {
        flechaNav.text = Formato.flecha(p.tipo)
        distNav.text = Formato.distancia(falta)
        textoNav.text = if (p.tipo == Route.LLEGADA) "Tu destino: $destTitulo" else p.texto()
    }

    private fun avanzarNavegacion(l: Location) {
        val r = ruta ?: return
        if (calculando) return
        var u = r.ubicar(l.latitude, l.longitude, segmentoActual - 3, segmentoActual + 80)
        if (u == null || u.fuera > 40.0) {
            val g = r.ubicar(l.latitude, l.longitude)
            if (g != null && (u == null || g.fuera < u.fuera)) u = g
        }
        if (u == null) return
        val tolerancia = Math.max(35.0, l.accuracy * 1.5)
        if (u.fuera > tolerancia) {
            fueraCont++
            if (fueraCont >= 3) reruteo()
            return
        }
        fueraCont = 0
        segmentoActual = u.segmento
        val progreso = u.progreso

        var prox = 1
        while (prox < r.pasos.size - 1 && r.pasos[prox].desde <= progreso + 3) prox++
        if (prox >= r.pasos.size) prox = r.pasos.size - 1
        val p = r.pasos[prox]
        val falta = Math.max(0.0, p.desde - progreso)
        actualizarBanner(p, falta)

        val restante = Math.max(0.0, r.distancia - progreso)
        val segundos = if (r.distancia > 0) r.tiempo * restante / r.distancia else 0.0
        val llegada = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(System.currentTimeMillis() + (segundos * 1000).toLong()))
        resumenNav?.text = "${Formato.distancia(restante)} · ${Formato.tiempo(segundos)} · llegás ${llegada}"

        anunciar(r, prox, falta)
        if (prox == r.pasos.size - 1 && falta < 25.0) terminarNavegacion(true)
    }

    private fun anunciar(r: Route, j: Int, falta: Double) {
        val p = r.pasos[j]
        val desdeAnterior = p.desde - r.pasos[Math.max(0, j - 1)].desde
        val lejos = j * 10
        val cerca = j * 10 + 1
        if (falta <= 350.0 && desdeAnterior > 450.0 && !anunciados.contains(lejos)) {
            anunciados.add(lejos)
            hablar(Formato.avisoLejano(p, falta))
        }
        if (falta <= 90.0 && p.tipo != Route.LLEGADA && !anunciados.contains(cerca)) {
            anunciados.add(cerca)
            anunciados.add(lejos)
            hablar(p.texto())
        }
    }

    private fun reruteo() {
        val ahora = System.currentTimeMillis()
        if (calculando || ahora - ultimoReruteo < 8000L) return
        ultimoReruteo = ahora
        fueraCont = 0
        textoNav.text = "Recalculando…"
        hablar("Recalculando")
        calcularRuta(true)
    }

    private fun terminarNavegacion(llego: Boolean) {
        navegando = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        bannerNav.visibility = View.GONE
        arriba.visibility = View.VISIBLE
        if (llego) {
            hablar("Llegaste a tu destino")
            Toast.makeText(this, "Llegaste a tu destino", Toast.LENGTH_LONG).show()
        } else {
            try { tts?.stop() } catch (e: Exception) { }
        }
        limpiarRuta()
    }

    // ------------------------------------------------------------------ voz

    private fun iniciarVoz() {
        tts = TextToSpeech(this) { estadoVoz ->
            if (estadoVoz == TextToSpeech.SUCCESS) {
                val t = tts
                if (t != null) {
                    var r = t.setLanguage(Locale("es", "AR"))
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                        r = t.setLanguage(Locale("es"))
                    }
                    ttsListo = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                }
            }
        }
    }

    private fun hablar(texto: String) {
        if (!vozActiva || !ttsListo) return
        try {
            tts?.speak(texto, TextToSpeech.QUEUE_FLUSH, null, "nav")
        } catch (e: Exception) {
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            navegando -> terminarNavegacion(false)
            scrollResultados.visibility == View.VISIBLE -> ocultarResultados()
            pines.isNotEmpty() -> quitarPines()
            hayDestino -> limpiarRuta()
            else -> super.onBackPressed()
        }
    }

    companion object {
        private const val PEDIDO_UBICACION = 10
        private const val PEDIDO_ARCHIVO = 11
    }
}
