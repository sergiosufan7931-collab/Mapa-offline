package com.mapaoffline.gps

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import org.mapsforge.core.model.LatLong
import org.mapsforge.map.android.graphics.AndroidGraphicFactory
import org.mapsforge.map.android.util.AndroidUtil
import org.mapsforge.map.android.view.MapView
import org.mapsforge.map.layer.cache.TileCache
import org.mapsforge.map.layer.overlay.Marker
import org.mapsforge.map.layer.renderer.TileRendererLayer
import org.mapsforge.map.reader.MapFile
import org.mapsforge.map.rendertheme.InternalRenderTheme
import java.io.File

/**
 * Fase 1: mapa sin conexión + ubicación GPS.
 * - El mapa se baja una vez con internet (o se elige un archivo .map) y después se usa sin conexión.
 * - La ubicación viene del GPS del teléfono y no se envía a ningún lado.
 */
class MainActivity : Activity() {

    private enum class Estado { SIN_MAPA, BAJANDO, LISTO }

    private val main = Handler(Looper.getMainLooper())

    private lateinit var mapView: MapView
    private lateinit var estado: TextView
    private lateinit var panel: LinearLayout
    private lateinit var botones: LinearLayout

    private var tileCache: TileCache? = null
    private var capaMapa: TileRendererLayer? = null
    private var marcador: Marker? = null
    private var ubicacion: Location? = null
    private var ultimaFijacion = 0L
    private var seguir = true
    private var mapaActual: File? = null

    private var estadoApp = Estado.SIN_MAPA
    private var bajada: Downloader? = null
    private var barra: ProgressBar? = null
    private var textoProgreso: TextView? = null
    private var mensajeError: String? = null

    // cursor que representa tu posición (se elige en el botón ▲)
    private val estilos = listOf("Punto", "Flecha", "Moto", "Auto", "Camioneta")
    private var cursorEstilo = 1
    private var rumboCursor = 0f
    private var rumboDibujado = -999f
    private var estiloDibujado = -1

    private val lm by lazy { getSystemService(LOCATION_SERVICE) as LocationManager }
    private var gpsActivo = false

    private val oyente = object : LocationListener {
        override fun onLocationChanged(l: Location) { alRecibirUbicacion(l) }
        @Deprecated("Solo para Android anterior a 10")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) { actualizarEstadoGps() }
        override fun onProviderDisabled(provider: String) { actualizarEstadoGps() }
    }

    private val vigilante = object : Runnable {
        override fun run() {
            actualizarEstadoGps()
            main.postDelayed(this, 2000)
        }
    }

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidGraphicFactory.createInstance(application)
        cursorEstilo = getSharedPreferences("mapa", MODE_PRIVATE).getInt("cursor", 1)
        construirPantalla()
        MapStore.cleanParts(this)
        val guardados = MapStore.installed(this)
        val ultimo = getSharedPreferences("mapa", MODE_PRIVATE).getString("actual", null)
        val elegido = guardados.firstOrNull { it.name == ultimo } ?: guardados.firstOrNull()
        if (elegido != null) abrirMapa(elegido) else mostrarEstado(Estado.SIN_MAPA)
    }

    override fun onStart() {
        super.onStart()
        pedirPermisoYEmpezar()
        main.post(vigilante)
    }

    override fun onStop() {
        super.onStop()
        detenerGps()
        main.removeCallbacks(vigilante)
    }

    override fun onDestroy() {
        bajada?.cancelar()
        quitarMapa()
        try { mapView.destroyAll() } catch (e: Exception) { }
        AndroidGraphicFactory.clearResourceMemoryCache()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ pantalla

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun fondo(color: Int, radio: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radio).toFloat()
        }

    private fun texto(t: String, tam: Float, color: Int = Color.WHITE, negrita: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = tam
            setTextColor(color)
            if (negrita) setTypeface(typeface, Typeface.BOLD)
        }

    private fun boton(t: String, principal: Boolean, accion: () -> Unit): Button =
        Button(this).apply {
            text = t
            isAllCaps = false
            textSize = 16f
            setTextColor(if (principal) Color.WHITE else 0xFF0B3D5C.toInt())
            background = fondo(if (principal) 0xFF1976D2.toInt() else 0xFFE3EEF7.toInt(), 14)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { accion() }
        }

    private fun botonRedondo(t: String, accion: () -> Unit): TextView =
        texto(t, 24f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = fondo(0xE60B3D5C.toInt(), 28)
            setOnClickListener { accion() }
        }

    private fun construirPantalla() {
        val raiz = FrameLayout(this)
        raiz.fitsSystemWindows = true

        mapView = MapView(this)
        mapView.isClickable = true
        mapView.mapScaleBar.isVisible = true
        mapView.model.mapViewPosition.setZoomLevelMin(8.toByte())
        mapView.model.mapViewPosition.setZoomLevelMax(20.toByte())
        mapView.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_MOVE) seguir = false
            false
        }
        raiz.addView(mapView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // barra de arriba: estado del GPS y acceso a los mapas
        val arriba = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = fondo(0xE60B3D5C.toInt(), 16)
            setPadding(dp(14), dp(8), dp(8), dp(8))
        }
        estado = texto("Iniciando…", 15f)
        arriba.addView(estado, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        arriba.addView(
            boton("Mapas", false) { mostrarMapas() }.apply { textSize = 14f },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        raiz.addView(
            arriba,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(10), dp(10), dp(10), 0)
            }
        )

        // botones a la derecha: acercar, alejar, centrar
        botones = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val lado = dp(56)
        fun lp() = LinearLayout.LayoutParams(lado, lado).apply { topMargin = dp(10) }
        botones.addView(botonRedondo("+") { mapView.model.mapViewPosition.zoomIn() }, lp())
        botones.addView(botonRedondo("−") { mapView.model.mapViewPosition.zoomOut() }, lp())
        botones.addView(botonRedondo("◎") { centrarEnMi() }, lp())
        botones.addView(botonRedondo("▲") { mostrarCursores() }, lp())
        raiz.addView(
            botones,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.BOTTOM).apply {
                setMargins(0, 0, dp(12), dp(36))
            }
        )

        // atribución obligatoria de OpenStreetMap
        raiz.addView(
            texto("© OpenStreetMap", 11f, 0xFF333333.toInt()).apply {
                setPadding(dp(6), dp(2), dp(6), dp(2))
                background = fondo(0xB3FFFFFF.toInt(), 6)
            },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.BOTTOM).apply {
                setMargins(dp(8), 0, 0, dp(8))
            }
        )

        // panel de abajo: sin mapa / descargando
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = fondo(0xF20B3D5C.toInt(), 20)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            visibility = View.GONE
        }
        raiz.addView(
            panel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
                setMargins(dp(10), 0, dp(10), dp(10))
            }
        )

        setContentView(raiz)
    }

    private fun mostrarEstado(e: Estado) {
        estadoApp = e
        botones.visibility = if (e == Estado.LISTO) View.VISIBLE else View.GONE
        panel.removeAllViews()
        barra = null
        textoProgreso = null
        if (e == Estado.LISTO) {
            panel.visibility = View.GONE
            return
        }
        panel.visibility = View.VISIBLE
        val reg = Config.REGIONES.first()
        if (e == Estado.SIN_MAPA) {
            panel.addView(texto("Todavía no tenés ningún mapa", 20f, Color.WHITE, true))
            panel.addView(
                texto(
                    "Bajá el mapa con internet una sola vez. Después se usa sin conexión, incluso en modo avión.",
                    15f, 0xFFCFE3F2.toInt()
                ).apply { setPadding(0, dp(6), 0, dp(12)) }
            )
            mensajeError?.let {
                panel.addView(texto(it, 15f, 0xFFFFB4A8.toInt(), true).apply { setPadding(0, 0, 0, dp(12)) })
            }
            panel.addView(boton("Bajar ${reg.nombre}", true) { empezarDescarga(reg) })
            panel.addView(
                boton("Elegir un archivo .map del teléfono", false) { elegirArchivo() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
            )
        } else {
            panel.addView(texto("Bajando el mapa…", 20f, Color.WHITE, true))
            val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000; isIndeterminate = true }
            panel.addView(pb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)).apply { topMargin = dp(12) })
            val tp = texto("Conectando…", 15f, 0xFFCFE3F2.toInt())
            panel.addView(tp, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
            panel.addView(
                boton("Cancelar", false) { bajada?.cancelar() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) }
            )
            barra = pb
            textoProgreso = tp
        }
    }

    // ------------------------------------------------------------------ mapas

    private fun abrirMapa(archivo: File): Boolean {
        return try {
            val datos = MapFile(archivo)
            quitarMapa()
            val cache = AndroidUtil.createTileCache(
                this, "tiles-" + archivo.nameWithoutExtension,
                mapView.model.displayModel.tileSize, 1f, mapView.model.frameBufferModel.overdrawFactor
            )
            val capa = TileRendererLayer(cache, datos, mapView.model.mapViewPosition, AndroidGraphicFactory.INSTANCE)
            capa.setXmlRenderTheme(InternalRenderTheme.DEFAULT)
            mapView.layerManager.layers.add(0, capa)
            tileCache = cache
            capaMapa = capa
            mapaActual = archivo
            getSharedPreferences("mapa", MODE_PRIVATE).edit().putString("actual", archivo.name).apply()

            val caja = datos.boundingBox()
            val yo = ubicacion
            if (yo != null && caja.contains(LatLong(yo.latitude, yo.longitude))) {
                mapView.setCenter(LatLong(yo.latitude, yo.longitude))
                mapView.setZoomLevel(16.toByte())
            } else {
                mapView.setCenter(caja.centerPoint)
                mapView.setZoomLevel(12.toByte())
            }
            mensajeError = null
            mostrarEstado(Estado.LISTO)
            ubicacion?.let { ponerMarcador(it) }
            true
        } catch (e: Throwable) {
            mensajeError = "No se pudo abrir el mapa: ${e.message ?: "archivo dañado"}."
            mostrarEstado(Estado.SIN_MAPA)
            false
        }
    }

    private fun quitarMapa() {
        capaMapa?.let {
            try { mapView.layerManager.layers.remove(it) } catch (e: Exception) { }
            try { it.onDestroy() } catch (e: Exception) { }
        }
        capaMapa = null
        try { tileCache?.destroy() } catch (e: Exception) { }
        tileCache = null
        mapaActual = null
    }

    private fun empezarDescarga(region: Region) {
        if (bajada != null) return
        mensajeError = null
        mostrarEstado(Estado.BAJANDO)
        val d = Downloader(applicationContext, { hecho, total -> mostrarProgreso(hecho, total) }, { res, archivo -> terminarTarea(res, archivo) })
        bajada = d
        d.bajar(region)
    }

    private fun elegirArchivo() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, PEDIDO_ARCHIVO)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PEDIDO_ARCHIVO || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (bajada != null) return
        mensajeError = null
        mostrarEstado(Estado.BAJANDO)
        val d = Downloader(applicationContext, { hecho, total -> mostrarProgreso(hecho, total) }, { res, archivo -> terminarTarea(res, archivo) })
        bajada = d
        d.importar(uri)
    }

    private fun mostrarProgreso(hecho: Long, total: Long) {
        val pb = barra ?: return
        val tp = textoProgreso ?: return
        if (total > 0) {
            pb.isIndeterminate = false
            pb.progress = ((hecho * 1000) / total).toInt()
            tp.text = "${hecho / 1048576} de ${total / 1048576} MB"
        } else {
            tp.text = "${hecho / 1048576} MB"
        }
    }

    private fun terminarTarea(res: Resultado, archivo: File?) {
        bajada = null
        when (res) {
            is Resultado.Ok -> {
                if (archivo != null && abrirMapa(archivo)) return
                if (mapaActual == null) mostrarEstado(Estado.SIN_MAPA)
            }
            is Resultado.Cancelado -> {
                mensajeError = null
                mostrarEstado(if (mapaActual != null) Estado.LISTO else Estado.SIN_MAPA)
            }
            is Resultado.Error -> {
                mensajeError = res.mensaje
                mostrarEstado(if (mapaActual != null) Estado.LISTO else Estado.SIN_MAPA)
                if (mapaActual != null) estado.text = res.mensaje
            }
        }
    }

    private fun mostrarMapas() {
        val caja = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(4))
        }
        val lista = MapStore.installed(this)
        if (lista.isEmpty()) {
            caja.addView(texto("No hay mapas instalados.", 16f, 0xFF222222.toInt()))
        }
        var dialogo: AlertDialog? = null
        for (f in lista) {
            val fila = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val activo = f == mapaActual
            fila.addView(texto(MapStore.niceName(f) + if (activo) "  (en uso)" else "", 16f, 0xFF0B3D5C.toInt(), true))
            fila.addView(texto(MapStore.sizeText(f), 13f, 0xFF555555.toInt()))
            val acciones = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            if (!activo) {
                acciones.addView(boton("Usar", true) { dialogo?.dismiss(); abrirMapa(f) })
            }
            acciones.addView(
                boton("Eliminar", false) {
                    dialogo?.dismiss()
                    confirmarBorrado(f)
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) }
            )
            fila.addView(acciones, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
            caja.addView(fila)
        }
        val reg = Config.REGIONES.first()
        caja.addView(
            boton("Bajar o actualizar ${reg.nombre}", true) { dialogo?.dismiss(); empezarDescarga(reg) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) }
        )
        caja.addView(
            boton("Elegir un archivo .map", false) { dialogo?.dismiss(); elegirArchivo() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
        )
        val scroll = ScrollView(this).apply { addView(caja) }
        val d = AlertDialog.Builder(this).setTitle("Mapas sin conexión").setView(scroll).setNegativeButton("Cerrar", null).create()
        dialogo = d
        d.show()
    }

    private fun confirmarBorrado(f: File) {
        AlertDialog.Builder(this)
            .setTitle("¿Eliminar este mapa?")
            .setMessage("${MapStore.niceName(f)} (${MapStore.sizeText(f)}). Para volver a usarlo hay que bajarlo de nuevo.")
            .setPositiveButton("Eliminar") { _, _ ->
                val eraElActual = f == mapaActual
                if (eraElActual) quitarMapa()
                f.delete()
                if (eraElActual) {
                    val otro = MapStore.installed(this).firstOrNull()
                    if (otro != null) abrirMapa(otro) else mostrarEstado(Estado.SIN_MAPA)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ------------------------------------------------------------------ GPS

    private fun tienePermiso(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun pedirPermisoYEmpezar() {
        if (tienePermiso()) {
            empezarGps()
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), PEDIDO_UBICACION)
            actualizarEstadoGps()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PEDIDO_UBICACION) {
            if (tienePermiso()) empezarGps() else actualizarEstadoGps()
        }
    }

    private fun empezarGps() {
        if (gpsActivo || !tienePermiso()) return
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, oyente)
                gpsActivo = true
            }
            val ultima = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (ultima != null && ubicacion == null) alRecibirUbicacion(ultima, false)
        } catch (e: SecurityException) {
            // sin permiso: se avisa en la barra de estado
        }
        actualizarEstadoGps()
    }

    private fun detenerGps() {
        try { lm.removeUpdates(oyente) } catch (e: Exception) { }
        gpsActivo = false
    }

    private fun alRecibirUbicacion(l: Location, fresca: Boolean = true) {
        ubicacion = l
        if (fresca) ultimaFijacion = System.currentTimeMillis()
        ponerMarcador(l)
        if (seguir && capaMapa != null) mapView.setCenter(LatLong(l.latitude, l.longitude))
        actualizarEstadoGps()
    }

    private fun ponerMarcador(l: Location) {
        if (capaMapa == null) return
        if (l.hasBearing() && l.hasSpeed() && l.speed > 1f) rumboCursor = l.bearing
        val pos = LatLong(l.latitude, l.longitude)
        val m = marcador
        val cambio = estiloDibujado != cursorEstilo ||
            (cursorEstilo != 0 && diferenciaAngulo(rumboCursor, rumboDibujado) >= 8f)
        if (m == null || cambio) {
            if (m != null) {
                try { mapView.layerManager.layers.remove(m) } catch (e: Exception) { }
            }
            val nuevo = Marker(pos, cursorBitmap(), 0, 0)
            mapView.layerManager.layers.add(nuevo)
            marcador = nuevo
            estiloDibujado = cursorEstilo
            rumboDibujado = rumboCursor
        } else {
            m.latLong = pos
            m.requestRedraw()
        }
    }

    private fun diferenciaAngulo(a: Float, b: Float): Float {
        var d = Math.abs(a - b) % 360f
        if (d > 180f) d = 360f - d
        return d
    }

    private fun cursorBitmap(): org.mapsforge.core.graphics.Bitmap =
        AndroidGraphicFactory.convertToBitmap(BitmapDrawable(resources, dibujarCursor(cursorEstilo, rumboCursor, dp(48))))

    /** Dibuja el cursor visto desde arriba, apuntando hacia "rumbo" grados (0 = norte). */
    private fun dibujarCursor(estilo: Int, rumbo: Float, tam: Int): android.graphics.Bitmap {
        val bmp = android.graphics.Bitmap.createBitmap(tam, tam, android.graphics.Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val azul = 0xFF1976D2.toInt()
        val oscuro = 0xFF14283A.toInt()
        val relleno = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = azul }
        val borde = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 0.09f; strokeJoin = Paint.Join.ROUND }
        val negro = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = oscuro }
        val cx = tam / 2f
        val cy = tam / 2f
        if (estilo == 0) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = Color.WHITE
            c.drawCircle(cx, cy, tam * 0.30f, p)
            p.color = azul
            c.drawCircle(cx, cy, tam * 0.22f, p)
            return bmp
        }
        val u = tam * 0.7f
        c.save()
        c.translate(cx, cy)
        c.rotate(rumbo)
        c.scale(u, u)
        fun caja(x1: Float, y1: Float, x2: Float, y2: Float, radio: Float, color: Int, conBorde: Boolean) {
            val r = RectF(x1, y1, x2, y2)
            if (conBorde) c.drawRoundRect(r, radio, radio, borde)
            val pr = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = color }
            c.drawRoundRect(r, radio, radio, pr)
        }
        when (estilo) {
            1 -> {
                val f = Path().apply {
                    moveTo(0f, -0.5f); lineTo(0.38f, 0.46f); lineTo(0f, 0.22f); lineTo(-0.38f, 0.46f); close()
                }
                c.drawPath(f, borde)
                c.drawPath(f, relleno)
            }
            2 -> {
                caja(-0.06f, -0.5f, 0.06f, -0.2f, 0.05f, oscuro, false)
                caja(-0.07f, 0.18f, 0.07f, 0.5f, 0.05f, oscuro, false)
                caja(-0.09f, -0.32f, 0.09f, 0.3f, 0.08f, azul, true)
                val manubrioB = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 0.13f; strokeCap = Paint.Cap.ROUND }
                val manubrio = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = oscuro; strokeWidth = 0.07f; strokeCap = Paint.Cap.ROUND }
                c.drawLine(-0.34f, -0.26f, 0.34f, -0.26f, manubrioB)
                c.drawLine(-0.34f, -0.26f, 0.34f, -0.26f, manubrio)
                caja(-0.2f, -0.2f, 0.2f, 0.06f, 0.1f, 0xFF64B5F6.toInt(), true)
                val casco = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xFFFFC107.toInt() }
                c.drawCircle(0f, -0.04f, 0.11f, casco)
            }
            3 -> {
                caja(-0.28f, -0.34f, -0.19f, -0.13f, 0.03f, oscuro, false)
                caja(0.19f, -0.34f, 0.28f, -0.13f, 0.03f, oscuro, false)
                caja(-0.28f, 0.15f, -0.19f, 0.36f, 0.03f, oscuro, false)
                caja(0.19f, 0.15f, 0.28f, 0.36f, 0.03f, oscuro, false)
                caja(-0.22f, -0.47f, 0.22f, 0.47f, 0.13f, azul, true)
                caja(-0.16f, -0.24f, 0.16f, -0.07f, 0.04f, 0xFFB3E5FC.toInt(), false)
                caja(-0.16f, -0.04f, 0.16f, 0.17f, 0.04f, 0xFF0D47A1.toInt(), false)
                caja(-0.15f, 0.2f, 0.15f, 0.31f, 0.04f, 0xFFB3E5FC.toInt(), false)
            }
            else -> {
                caja(-0.28f, -0.38f, -0.19f, -0.17f, 0.03f, oscuro, false)
                caja(0.19f, -0.38f, 0.28f, -0.17f, 0.03f, oscuro, false)
                caja(-0.28f, 0.2f, -0.19f, 0.41f, 0.03f, oscuro, false)
                caja(0.19f, 0.2f, 0.28f, 0.41f, 0.03f, oscuro, false)
                caja(-0.22f, -0.5f, 0.22f, 0.5f, 0.08f, azul, true)
                caja(-0.18f, -0.43f, 0.18f, -0.04f, 0.05f, 0xFF0D47A1.toInt(), false)
                caja(-0.14f, -0.38f, 0.14f, -0.24f, 0.03f, 0xFFB3E5FC.toInt(), false)
                caja(-0.17f, 0.02f, 0.17f, 0.45f, 0.03f, 0xFF455A64.toInt(), false)
            }
        }
        c.restore()
        return bmp
    }

    private fun mostrarCursores() {
        val caja = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(4))
        }
        var dialogo: AlertDialog? = null
        estilos.forEachIndexed { i, nombre ->
            val fila = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(8), dp(8), dp(8))
                background = fondo(if (i == cursorEstilo) 0xFFD6E6F3.toInt() else Color.TRANSPARENT, 12)
            }
            val img = ImageView(this).apply {
                setImageBitmap(dibujarCursor(i, 0f, dp(56)))
                background = fondo(0xFF8FA3B3.toInt(), 12)
            }
            fila.addView(img, LinearLayout.LayoutParams(dp(56), dp(56)))
            fila.addView(
                texto(nombre + if (i == cursorEstilo) "  ✓" else "", 18f, 0xFF0B3D5C.toInt(), true).apply { setPadding(dp(14), 0, 0, 0) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            fila.setOnClickListener {
                elegirCursor(i)
                dialogo?.dismiss()
            }
            caja.addView(fila, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) })
        }
        val scroll = ScrollView(this).apply { addView(caja) }
        val d = AlertDialog.Builder(this).setTitle("Elegí tu cursor").setView(scroll).setNegativeButton("Cerrar", null).create()
        dialogo = d
        d.show()
    }

    private fun elegirCursor(i: Int) {
        cursorEstilo = i
        getSharedPreferences("mapa", MODE_PRIVATE).edit().putInt("cursor", i).apply()
        ubicacion?.let { ponerMarcador(it) }
    }

    private fun centrarEnMi() {
        val l = ubicacion
        if (l == null) {
            estado.text = "Todavía no hay ubicación. Salí a un lugar abierto."
            return
        }
        seguir = true
        mapView.setCenter(LatLong(l.latitude, l.longitude))
        if (mapView.model.mapViewPosition.zoomLevel < 15) mapView.setZoomLevel(16.toByte())
    }

    private fun rumbo(grados: Float): String {
        val n = arrayOf("N", "NE", "E", "SE", "S", "SO", "O", "NO")
        return n[(((grados + 22.5f) % 360f) / 45f).toInt().coerceIn(0, 7)]
    }

    private fun actualizarEstadoGps() {
        if (bajada != null) return
        if (!tienePermiso()) {
            estado.text = "Falta el permiso de ubicación"
            return
        }
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            estado.text = "El GPS está apagado. Activalo en los ajustes."
            return
        }
        if (!gpsActivo) empezarGps()
        val l = ubicacion
        val hace = System.currentTimeMillis() - ultimaFijacion
        if (l == null || ultimaFijacion == 0L) {
            estado.text = "Buscando señal GPS…"
        } else if (hace > 8000) {
            estado.text = "Señal GPS perdida, buscando…"
        } else {
            var t = "GPS ±${l.accuracy.toInt()} m"
            if (l.hasSpeed()) t += " · ${(l.speed * 3.6f).toInt()} km/h"
            if (l.hasBearing() && l.hasSpeed() && l.speed > 1f) t += " · ${rumbo(l.bearing)}"
            estado.text = t
        }
    }

    companion object {
        private const val PEDIDO_UBICACION = 10
        private const val PEDIDO_ARCHIVO = 11
    }
}
