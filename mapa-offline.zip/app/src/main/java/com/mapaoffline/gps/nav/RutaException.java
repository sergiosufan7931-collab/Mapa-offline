package com.mapaoffline.gps.nav;

/** No se pudo calcular la ruta; el mensaje se le muestra a la persona. */
public class RutaException extends Exception {
    public RutaException(String mensaje) { super(mensaje); }
}
