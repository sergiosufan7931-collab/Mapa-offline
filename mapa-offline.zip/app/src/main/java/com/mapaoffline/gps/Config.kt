package com.mapaoffline.gps

/** Una región de mapa que se puede bajar con internet y usar sin conexión. */
data class Region(val id: String, val nombre: String, val url: String)

object Config {
    /** Repositorio de GitHub donde el workflow "Generar mapa" publica los paquetes. Cambiar acá si el repositorio se llama distinto. */
    const val REPO = "sergiosufan7931-collab/mapa-offline"

    val REGIONES: List<Region> = listOf(
        Region(
            "buenos-aires",
            "Buenos Aires (CABA y Gran Buenos Aires)",
            "https://github.com/$REPO/releases/download/mapas/buenos-aires.map"
        )
    )
}
