package com.mapaoffline.gps

import com.mapaoffline.gps.nav.Route
import java.util.Locale

/** Textos de distancias, tiempos e indicaciones, en castellano rioplatense. */
object Formato {
    private val ar = Locale("es", "AR")

    /** Para mostrar en pantalla: "350 m" o "2,4 km". */
    fun distancia(m: Double): String =
        if (m < 950.0) "${Math.max(0L, Math.round(m / 10.0) * 10)} m"
        else String.format(ar, "%.1f km", m / 1000.0)

    /** "12 min" o "1 h 5 min". */
    fun tiempo(s: Double): String {
        val min = Math.round(s / 60.0).toInt()
        return when {
            min < 1 -> "menos de 1 min"
            min < 60 -> "$min min"
            else -> "${min / 60} h ${min % 60} min"
        }
    }

    /** Para decir en voz alta: "300 metros" o "1,5 kilómetros". */
    fun voz(m: Double): String {
        if (m < 950.0) {
            val r = (Math.round(m / 50.0) * 50).toInt().coerceAtLeast(50)
            return "$r metros"
        }
        return String.format(ar, "%.1f", m / 1000.0) + " kilómetros"
    }

    private fun minuscula(t: String): String =
        if (t.isEmpty()) t else t.substring(0, 1).lowercase(ar) + t.substring(1)

    /** Aviso anticipado: "En 300 metros, doblá a la derecha en Calle X". */
    fun avisoLejano(p: Route.Paso, falta: Double): String =
        if (p.tipo == Route.LLEGADA) "Tu destino está a ${voz(falta)}"
        else "En ${voz(falta)}, ${minuscula(p.texto())}"

    /** Flecha grande de la pantalla de navegación. */
    fun flecha(tipo: Int): String = when (tipo) {
        Route.SALIDA, Route.SEGUI -> "↑"
        Route.LIG_DER -> "↗"
        Route.DER -> "→"
        Route.BRUSCO_DER -> "↘"
        Route.LIG_IZQ -> "↖"
        Route.IZQ -> "←"
        Route.BRUSCO_IZQ -> "↙"
        Route.GIRO_U -> "↶"
        Route.ROTONDA -> "↻"
        else -> "⚑"
    }
}
