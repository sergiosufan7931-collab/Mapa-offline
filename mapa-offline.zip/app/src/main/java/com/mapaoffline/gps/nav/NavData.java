package com.mapaoffline.gps.nav;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;

/**
 * Datos de calles y buscador cargados desde un archivo .nav (ver build_nav.py).
 * Lo grande (puntos de las curvas, direcciones, lugares) queda en el archivo y se lee a demanda;
 * en memoria solo queda lo que usa el cálculo de rutas.
 */
public final class NavData {
    public static final int MAGIC = 0x3156414E;

    public final int nV, nL, nShape, nNames, nAddr, nPoi;
    public final int minLat, minLon, maxLat, maxLon;

    public final int[] vLat, vLon;
    public final int[] lA, lB, lLen, lCost, lName, lFlags, lShapeStart;
    /** Tramos que se pueden recorrer saliendo de cada vértice: adjEntry = tramo*2 + (0 si va de A a B, 1 si va de B a A). */
    public final int[] adjStart, adjEntry;
    public final String[] names;

    final IntBuffer shapeLat, shapeLon;
    final IntBuffer addrStreet, addrNum, addrLat, addrLon;
    final IntBuffer poiLat, poiLon, poiKind, poiOff;
    final ByteBuffer poiBytes;

    // índice espacial para ubicar un punto sobre la calle más cercana
    static final int CELDA = 2000; // microgrados (unos 200 m)
    final int gW, gH;
    final int[] gStart, gList;

    // tramos de cada nombre de calle
    final int[] nameLinkStart, nameLinkList;

    private static IntBuffer seccion(ByteBuffer mb, long off, int n) {
        ByteBuffer d = mb.duplicate();
        d.position((int) off);
        d.limit((int) (off + 4L * n));
        return d.slice().order(ByteOrder.LITTLE_ENDIAN).asIntBuffer();
    }

    private static int[] leer(ByteBuffer mb, long off, int n) {
        int[] a = new int[n];
        seccion(mb, off, n).get(a);
        return a;
    }

    /** Comprueba el encabezado y el tamaño del archivo sin cargarlo entero. */
    public static boolean esValido(File f) {
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile(f, "r");
            long tam = raf.length();
            if (tam < 56) return false;
            byte[] b = new byte[56];
            raf.readFully(b);
            IntBuffer h = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).asIntBuffer();
            if (h.get(0) != MAGIC || h.get(1) != 1) return false;
            long nV = h.get(2), nL = h.get(3), nShape = h.get(4), nNames = h.get(5), nameInts = h.get(6);
            long nAddr = h.get(7), nPoi = h.get(8), poiInts = h.get(9);
            long need = 56L + 4L * (2L * nV + 6L * nL + (nL + 1) + 2L * nShape + (nNames + 1) + nameInts
                    + 4L * nAddr + 3L * nPoi + (nPoi + 1) + poiInts);
            return need == tam;
        } catch (IOException e) {
            return false;
        } finally {
            if (raf != null) {
                try { raf.close(); } catch (IOException e) { /* nada */ }
            }
        }
    }

    public static NavData cargar(File f) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(f, "r");
        try {
            FileChannel ch = raf.getChannel();
            long tam = ch.size();
            ByteBuffer mb = ch.map(FileChannel.MapMode.READ_ONLY, 0, tam);
            mb.order(ByteOrder.LITTLE_ENDIAN);
            return new NavData(mb, tam);
        } finally {
            raf.close(); // el mapeo sigue válido después de cerrar el archivo
        }
    }

    private NavData(ByteBuffer mb, long tam) throws IOException {
        if (tam < 56) throw new IOException("Archivo de rutas incompleto");
        IntBuffer h = seccion(mb, 0, 14);
        if (h.get(0) != MAGIC) throw new IOException("No es un archivo de rutas válido");
        if (h.get(1) != 1) throw new IOException("Versión de rutas no compatible");
        nV = h.get(2); nL = h.get(3); nShape = h.get(4); nNames = h.get(5);
        int nameInts = h.get(6);
        nAddr = h.get(7); nPoi = h.get(8);
        int poiInts = h.get(9);
        minLat = h.get(10); minLon = h.get(11); maxLat = h.get(12); maxLon = h.get(13);

        long need = 56L + 4L * (2L * nV + 6L * nL + (nL + 1) + 2L * nShape + (nNames + 1) + nameInts
                + 4L * nAddr + 3L * nPoi + (nPoi + 1) + poiInts);
        if (need != tam) throw new IOException("Archivo de rutas dañado o incompleto");

        long p = 56;
        vLat = leer(mb, p, nV); p += 4L * nV;
        vLon = leer(mb, p, nV); p += 4L * nV;
        lA = leer(mb, p, nL); p += 4L * nL;
        lB = leer(mb, p, nL); p += 4L * nL;
        lLen = leer(mb, p, nL); p += 4L * nL;
        lCost = leer(mb, p, nL); p += 4L * nL;
        lName = leer(mb, p, nL); p += 4L * nL;
        lFlags = leer(mb, p, nL); p += 4L * nL;
        lShapeStart = leer(mb, p, nL + 1); p += 4L * (nL + 1);
        shapeLat = seccion(mb, p, nShape); p += 4L * nShape;
        shapeLon = seccion(mb, p, nShape); p += 4L * nShape;
        int[] nameOff = leer(mb, p, nNames + 1); p += 4L * (nNames + 1);
        ByteBuffer nb = mb.duplicate();
        names = new String[nNames];
        Charset utf8 = Charset.forName("UTF-8");
        for (int i = 0; i < nNames; i++) {
            int len = nameOff[i + 1] - nameOff[i];
            byte[] b = new byte[len];
            nb.position((int) (p + nameOff[i]));
            nb.get(b);
            names[i] = new String(b, utf8);
        }
        p += 4L * nameInts;
        addrStreet = seccion(mb, p, nAddr); p += 4L * nAddr;
        addrNum = seccion(mb, p, nAddr); p += 4L * nAddr;
        addrLat = seccion(mb, p, nAddr); p += 4L * nAddr;
        addrLon = seccion(mb, p, nAddr); p += 4L * nAddr;
        poiLat = seccion(mb, p, nPoi); p += 4L * nPoi;
        poiLon = seccion(mb, p, nPoi); p += 4L * nPoi;
        poiKind = seccion(mb, p, nPoi); p += 4L * nPoi;
        poiOff = seccion(mb, p, nPoi + 1); p += 4L * (nPoi + 1);
        ByteBuffer pb = mb.duplicate();
        pb.position((int) p);
        pb.limit((int) (p + 4L * poiInts));
        poiBytes = pb.slice();

        // sentidos de circulación
        int[] deg = new int[nV + 1];
        for (int l = 0; l < nL; l++) {
            int modo = (lFlags[l] >> 4) & 3;
            if (modo == 0 || modo == 1) deg[lA[l]]++;
            if (modo == 0 || modo == 2) deg[lB[l]]++;
        }
        adjStart = new int[nV + 1];
        for (int v = 0; v < nV; v++) adjStart[v + 1] = adjStart[v] + deg[v];
        adjEntry = new int[adjStart[nV]];
        int[] pos = new int[nV];
        for (int l = 0; l < nL; l++) {
            int modo = (lFlags[l] >> 4) & 3;
            if (modo == 0 || modo == 1) { int v = lA[l]; adjEntry[adjStart[v] + pos[v]++] = l * 2; }
            if (modo == 0 || modo == 2) { int v = lB[l]; adjEntry[adjStart[v] + pos[v]++] = l * 2 + 1; }
        }

        // tramos por nombre
        int[] cn = new int[nNames + 1];
        for (int l = 0; l < nL; l++) if (lName[l] >= 0) cn[lName[l] + 1]++;
        for (int i = 0; i < nNames; i++) cn[i + 1] += cn[i];
        nameLinkStart = cn;
        nameLinkList = new int[cn[nNames]];
        int[] pn = new int[nNames];
        for (int l = 0; l < nL; l++) {
            int nm = lName[l];
            if (nm >= 0) nameLinkList[cn[nm] + pn[nm]++] = l;
        }

        // cuadrícula para ubicar puntos sobre las calles
        gW = (maxLon - minLon) / CELDA + 1;
        gH = (maxLat - minLat) / CELDA + 1;
        int celdas = gW * gH;
        int[] cnt = new int[celdas + 1];
        int[] lista = null;
        for (int pasada = 0; pasada < 2; pasada++) {
            int[] fill = null;
            if (pasada == 1) {
                for (int i = 0; i < celdas; i++) cnt[i + 1] += cnt[i];
                fill = new int[celdas];
                lista = new int[cnt[celdas]];
            }
            for (int l = 0; l < nL; l++) {
                int n = puntos(l);
                int ultima = -1, penultima = -1;
                for (int i = 0; i + 1 < n; i++) {
                    int la1 = latDe(l, i), lo1 = lonDe(l, i), la2 = latDe(l, i + 1), lo2 = lonDe(l, i + 1);
                    int pasos = Math.max(Math.abs(la2 - la1), Math.abs(lo2 - lo1)) / (CELDA / 2) + 1;
                    for (int s = 0; s <= pasos; s++) {
                        int la = la1 + (int) ((long) (la2 - la1) * s / pasos);
                        int lo = lo1 + (int) ((long) (lo2 - lo1) * s / pasos);
                        int c = celdaDe(la, lo);
                        if (c < 0 || c == ultima || c == penultima) continue;
                        penultima = ultima;
                        ultima = c;
                        if (pasada == 0) cnt[c + 1]++; else lista[cnt[c] + fill[c]++] = l;
                    }
                }
            }
        }
        gStart = cnt;
        gList = lista;
    }

    // ------------------------------------------------------------------ geometría de los tramos

    /** Cantidad de puntos de un tramo, con los dos extremos. */
    public int puntos(int l) {
        return lShapeStart[l + 1] - lShapeStart[l] + 2;
    }

    public int latDe(int l, int i) {
        int n = puntos(l);
        if (i <= 0) return vLat[lA[l]];
        if (i >= n - 1) return vLat[lB[l]];
        return shapeLat.get(lShapeStart[l] + i - 1);
    }

    public int lonDe(int l, int i) {
        int n = puntos(l);
        if (i <= 0) return vLon[lA[l]];
        if (i >= n - 1) return vLon[lB[l]];
        return shapeLon.get(lShapeStart[l] + i - 1);
    }

    int celdaDe(int lat, int lon) {
        int cy = (lat - minLat) / CELDA;
        int cx = (lon - minLon) / CELDA;
        if (lat < minLat || lon < minLon || cx >= gW || cy >= gH) return -1;
        return cy * gW + cx;
    }

    public boolean dentro(double lat, double lon) {
        int la = (int) Math.round(lat * 1e6), lo = (int) Math.round(lon * 1e6);
        int margen = 3000;
        return la >= minLat - margen && la <= maxLat + margen && lo >= minLon - margen && lo <= maxLon + margen;
    }

    /** Resultado de ubicar un punto sobre la calle más cercana. */
    public static final class Punto {
        public int tramo;
        public double fraccion;   // 0 en el extremo A, 1 en el B
        public double lat, lon;   // punto sobre la calle
        public double distancia;  // metros desde el punto pedido hasta la calle
    }

    /** Calle más cercana a un punto, hasta "maxM" metros. Devuelve null si no hay ninguna. */
    public Punto ubicar(double lat, double lon, double maxM) {
        double kx = Geo.M_POR_GRADO * Math.cos(Math.toRadians(lat));
        double ky = Geo.M_POR_GRADO;
        int la = (int) Math.round(lat * 1e6), lo = (int) Math.round(lon * 1e6);
        int cx = Math.floorDiv(lo - minLon, CELDA);
        int cy = Math.floorDiv(la - minLat, CELDA);
        double celdaM = Math.min(CELDA * 1e-6 * kx, CELDA * 1e-6 * ky) * 0.9;
        int maxR = (int) Math.min(60, Math.ceil(maxM / celdaM) + 1);
        double mejor = Double.MAX_VALUE;
        Punto res = null;
        for (int r = 0; r <= maxR; r++) {
            for (int y = cy - r; y <= cy + r; y++) {
                if (y < 0 || y >= gH) continue;
                boolean borde = (y == cy - r || y == cy + r);
                for (int x = cx - r; x <= cx + r; x += (borde ? 1 : Math.max(1, 2 * r))) {
                    if (x < 0 || x >= gW) continue;
                    int c = y * gW + x;
                    for (int k = gStart[c]; k < gStart[c + 1]; k++) {
                        int l = gList[k];
                        Punto p = proyectar(l, lat, lon, kx, ky);
                        if (p.distancia < mejor) { mejor = p.distancia; res = p; }
                    }
                }
            }
            if (res != null && mejor <= r * celdaM) break;
        }
        if (res == null || res.distancia > maxM) return null;
        return res;
    }

    private Punto proyectar(int l, double lat, double lon, double kx, double ky) {
        int n = puntos(l);
        double[] cx = new double[n], cy = new double[n];
        for (int i = 0; i < n; i++) {
            cx[i] = (latDe(l, i) * 1e-6 - lat) * ky;   // y (norte)
            cy[i] = (lonDe(l, i) * 1e-6 - lon) * kx;   // x (este)
        }
        double total = 0, mejorD = Double.MAX_VALUE, mejorAlong = 0, bLat = 0, bLon = 0;
        double acum = 0;
        for (int i = 0; i + 1 < n; i++) {
            double ay = cx[i], ax = cy[i], by = cx[i + 1], bx = cy[i + 1];
            double dx = bx - ax, dy = by - ay;
            double seg = Math.sqrt(dx * dx + dy * dy);
            double t = seg < 1e-9 ? 0 : (-(ax) * dx - (ay) * dy) / (seg * seg);
            if (t < 0) t = 0;
            if (t > 1) t = 1;
            double px = ax + t * dx, py = ay + t * dy;
            double d = Math.sqrt(px * px + py * py);
            if (d < mejorD) {
                mejorD = d;
                mejorAlong = acum + t * seg;
                bLat = lat + py / ky;
                bLon = lon + px / kx;
            }
            acum += seg;
        }
        total = acum;
        Punto p = new Punto();
        p.tramo = l;
        p.fraccion = total < 1e-9 ? 0 : mejorAlong / total;
        p.lat = bLat;
        p.lon = bLon;
        p.distancia = mejorD;
        return p;
    }

    // ------------------------------------------------------------------ lugares y direcciones (lectura a demanda)

    public String nombreLugar(int i) {
        int a = poiOff.get(i), b = poiOff.get(i + 1);
        byte[] bytes = new byte[b - a];
        ByteBuffer d = poiBytes.duplicate();
        d.position(a);
        d.get(bytes);
        return new String(bytes, Charset.forName("UTF-8"));
    }
}
