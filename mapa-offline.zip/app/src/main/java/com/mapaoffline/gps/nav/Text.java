package com.mapaoffline.gps.nav;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Normaliza textos para buscar: sin tildes, en minúsculas y con las abreviaturas más comunes expandidas. */
public final class Text {
    private Text() {}

    private static final Map<String, String> ABREV = new HashMap<String, String>();
    private static final Set<String> GENERICAS = new HashSet<String>();

    static {
        String[][] a = {
            {"gral", "general"}, {"grl", "general"}, {"cnel", "coronel"}, {"cor", "coronel"}, {"dr", "doctor"},
            {"dra", "doctora"}, {"pte", "presidente"}, {"tte", "teniente"}, {"sgto", "sargento"},
            {"alte", "almirante"}, {"ing", "ingeniero"}, {"lic", "licenciado"}, {"mons", "monsenor"},
            {"av", "avenida"}, {"avda", "avenida"}, {"pje", "pasaje"}, {"bv", "bulevar"}, {"blvd", "bulevar"},
            {"boulevard", "bulevar"}, {"sta", "santa"}, {"cap", "capitan"}, {"fray", "fray"}
        };
        for (String[] p : a) ABREV.put(p[0], p[1]);
        String[] g = {"calle", "avenida", "pasaje", "bulevar", "diagonal", "autopista", "camino"};
        for (String s : g) GENERICAS.add(s);
    }

    /** Minúsculas, sin tildes ni signos, con espacios simples y abreviaturas expandidas. */
    public static String norm(String s) {
        if (s == null) return "";
        String t = Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        StringBuilder sb = new StringBuilder(t.length());
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (Character.getType(c) == Character.NON_SPACING_MARK) continue;
            if (c == '\u00f1') { sb.append('n'); continue; }
            if (Character.isLetterOrDigit(c)) sb.append(c); else sb.append(' ');
        }
        String[] tok = sb.toString().trim().split("\\s+");
        StringBuilder out = new StringBuilder();
        for (String w : tok) {
            if (w.isEmpty()) continue;
            String e = ABREV.get(w);
            if (out.length() > 0) out.append(' ');
            out.append(e != null ? e : w);
        }
        return out.toString();
    }

    public static boolean esGenerica(String palabra) {
        return GENERICAS.contains(palabra);
    }

    /** Palabras de un texto ya normalizado, sin las genéricas (calle, avenida...). Si todas son genéricas, las deja. */
    public static String[] clave(String normalizado) {
        if (normalizado.isEmpty()) return new String[0];
        String[] tok = normalizado.split(" ");
        ArrayList<String> r = new ArrayList<String>();
        for (String w : tok) if (!esGenerica(w)) r.add(w);
        if (r.isEmpty()) return tok;
        return r.toArray(new String[0]);
    }
}
