package com.mapaoffline.gps

import android.content.Context
import org.mapsforge.map.reader.MapFile
import java.io.File

/** Mapas guardados en el teléfono (carpeta privada de la app). */
object MapStore {
    fun dir(ctx: Context): File = File(ctx.filesDir, "maps").apply { mkdirs() }

    fun file(ctx: Context, id: String): File = File(dir(ctx), "$id.map")

    /** Datos de rutas y buscador de un mapa (mismo nombre, extensión .nav). */
    fun navFile(ctx: Context, id: String): File = File(dir(ctx), "$id.nav")

    fun installed(ctx: Context): List<File> =
        (dir(ctx).listFiles { f -> f.isFile && f.name.endsWith(".map") } ?: emptyArray<File>())
            .sortedBy { it.name }

    /** Un mapa sano se puede abrir y tiene su encabezado completo. */
    fun isValid(f: File): Boolean {
        if (!f.exists() || f.length() < 1024) return false
        return try {
            val m = MapFile(f)
            m.close()
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun cleanParts(ctx: Context) {
        dir(ctx).listFiles { f -> f.name.endsWith(".part") }?.forEach { it.delete() }
    }

    fun niceName(f: File): String {
        val id = f.nameWithoutExtension
        return Config.REGIONES.firstOrNull { it.id == id }?.nombre ?: id
    }

    fun sizeText(f: File): String = "%d MB".format(f.length() / (1024 * 1024))
}
