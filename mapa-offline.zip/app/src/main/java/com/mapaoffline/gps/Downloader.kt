package com.mapaoffline.gps

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.UnknownHostException

sealed class Resultado {
    object Ok : Resultado()
    object Cancelado : Resultado()
    class Error(val mensaje: String) : Resultado()
}

/**
 * Baja o importa un mapa sin pisar el que ya funciona: primero se escribe en un archivo .part,
 * se comprueba que esté completo y sano, y recién ahí reemplaza al anterior.
 */
class Downloader(
    private val ctx: Context,
    private val onProgress: (Long, Long) -> Unit,
    private val onFinish: (Resultado, File?) -> Unit
) {
    @Volatile private var cancelado = false
    private val main = Handler(Looper.getMainLooper())

    fun cancelar() { cancelado = true }

    fun bajar(region: Region) {
        Thread {
            var dest: File? = null
            val r: Resultado = try {
                dest = MapStore.file(ctx, region.id)
                descargar(region, dest)
            } catch (e: UnknownHostException) {
                Resultado.Error("No hay internet. Conectate para bajar el mapa.")
            } catch (e: IOException) {
                Resultado.Error("Se cortó la descarga: ${e.message ?: "error de red"}.")
            } catch (e: Exception) {
                Resultado.Error("No se pudo bajar el mapa: ${e.message ?: "error"}.")
            }
            main.post { onFinish(r, if (r is Resultado.Ok) dest else null) }
        }.start()
    }

    fun importar(uri: Uri) {
        Thread {
            var dest: File? = null
            val r: Resultado = try {
                var nombre = "importado"
                ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0 && c.moveToFirst()) nombre = c.getString(i).orEmpty()
                }
                nombre = nombre.removeSuffix(".map").replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { "importado" }
                val d = MapStore.file(ctx, nombre)
                dest = d
                val part = File(d.path + ".part")
                val input = ctx.contentResolver.openInputStream(uri) ?: return@Thread
                var total = 0L
                ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.SIZE)
                    if (i >= 0 && c.moveToFirst()) total = c.getLong(i)
                }
                if (total > 0 && StatFs(part.parent).availableBytes < total + 50L * 1024 * 1024) {
                    input.close()
                    Resultado.Error("No hay espacio en el teléfono para este archivo.")
                } else {
                    copiar(input, part, total) ?: terminar(part, d)
                }
            } catch (e: Exception) {
                Resultado.Error("No se pudo importar el archivo: ${e.message ?: "error"}.")
            }
            main.post { onFinish(r, if (r is Resultado.Ok) dest else null) }
        }.start()
    }

    private fun descargar(region: Region, dest: File): Resultado {
        val part = File(dest.path + ".part")
        val conn = URL(region.url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.instanceFollowRedirects = true
            val code = conn.responseCode
            if (code == 404) return Resultado.Error("Ese mapa todavía no está publicado. Primero hay que generarlo en GitHub (error 404).")
            if (code != 200) return Resultado.Error("El servidor respondió con el código $code.")
            val total = conn.contentLengthLong
            if (total > 0) {
                val libre = StatFs(part.parent).availableBytes
                if (libre < total + 50L * 1024 * 1024) {
                    return Resultado.Error("No hay espacio: hacen falta ${total / 1048576} MB y quedan ${libre / 1048576} MB libres.")
                }
            }
            val corte = copiar(conn.inputStream, part, total)
            if (corte != null) return corte
            return terminar(part, dest)
        } finally {
            conn.disconnect()
        }
    }

    /** Copia el flujo al archivo .part. Devuelve null si salió bien, o el motivo del corte. */
    private fun copiar(input: java.io.InputStream, part: File, total: Long): Resultado? {
        var hecho = 0L
        var ultimo = 0L
        input.use { ins ->
            part.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    if (cancelado) {
                        part.delete()
                        return Resultado.Cancelado
                    }
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    hecho += n
                    val ahora = System.currentTimeMillis()
                    if (ahora - ultimo > 300) {
                        ultimo = ahora
                        val h = hecho
                        main.post { onProgress(h, total) }
                    }
                }
            }
        }
        if (total > 0 && hecho != total) {
            part.delete()
            return Resultado.Error("La descarga quedó incompleta. Probá de nuevo.")
        }
        return null
    }

    /** Verifica el archivo y recién entonces reemplaza al mapa anterior. */
    private fun terminar(part: File, dest: File): Resultado {
        if (!MapStore.isValid(part)) {
            part.delete()
            return Resultado.Error("El archivo está dañado o no es un mapa válido. Se conserva el mapa anterior.")
        }
        if (dest.exists()) dest.delete()
        if (!part.renameTo(dest)) return Resultado.Error("No se pudo guardar el mapa.")
        return Resultado.Ok
    }
}
