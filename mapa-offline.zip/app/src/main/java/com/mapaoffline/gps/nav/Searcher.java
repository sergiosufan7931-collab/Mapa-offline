package com.mapaoffline.gps.nav;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Buscador sin conexión: calles, direcciones con altura, esquinas ("A y B"), barrios y lugares.
 * Las alturas que no están cargadas en el mapa se calculan entre las más cercanas (se avisa "aproximada").
 */
public final class Searcher {
    public static final int CALLE = 0, DIRECCION = 1, ESQUINA = 2, LUGAR = 3;

    public static final class Lugar {
        public String titulo, detalle;
        public double lat, lon;
        public int tipo;
        public double distancia;   // metros desde el punto de referencia
        int puntaje;
    }

    private static final String[] RUBROS = {
        "Lugar", "Comercio", "Comida", "Salud", "Transporte", "Combustible",
        "Educación", "Parque", "Barrio o localidad", "Servicios", "Turismo y cultura"
    };

    private static final Pattern CRUCE = Pattern.compile("^(.+?)\\s+(?:y|e|esq|esquina|con)\\s+(.+)$");
    private static final Pattern ALTURA = Pattern.compile("^(.*[a-z].*?)\\s+(\\d{1,6})$");

    private final NavData d;
    private final String[][] calleClave;
    private String[][] lugarClave;
    private String[] lugarNombre;

    public Searcher(NavData datos) {
        this.d = datos;
        calleClave = new String[d.nNames][];
        for (int i = 0; i < d.nNames; i++) calleClave[i] = Text.clave(Text.norm(d.names[i]));
    }

    private synchronized void prepararLugares() {
        if (lugarClave != null) return;
        String[] nom = new String[d.nPoi];
        String[][] clave = new String[d.nPoi][];
        for (int i = 0; i < d.nPoi; i++) {
            nom[i] = d.nombreLugar(i);
            clave[i] = Text.clave(Text.norm(nom[i]));
        }
        lugarNombre = nom;
        lugarClave = clave;
    }

    // ------------------------------------------------------------------ coincidencias

    /** -1 si no coincide; 0 es lo mejor. Cada palabra buscada tiene que ser el comienzo de una palabra del nombre. */
    private static int puntaje(String[] q, String[] n) {
        if (q.length == 0 || n.length == 0 || q.length > n.length) return -1;
        boolean[] usada = new boolean[n.length];
        boolean todasIguales = true;
        boolean primeraEnPrimera = false;
        for (int qi = 0; qi < q.length; qi++) {
            int hallada = -1;
            for (int j = 0; j < n.length && hallada < 0; j++) if (!usada[j] && n[j].equals(q[qi])) hallada = j;
            if (hallada < 0) {
                todasIguales = false;
                for (int j = 0; j < n.length && hallada < 0; j++) if (!usada[j] && n[j].startsWith(q[qi])) hallada = j;
            }
            if (hallada < 0) return -1;
            usada[hallada] = true;
            if (qi == 0 && hallada == 0) primeraEnPrimera = true;
        }
        if (todasIguales && q.length == n.length) return 0;
        if (primeraEnPrimera) return 1;
        return 2;
    }

    private List<Integer> buscarCalles(String texto, int limite) {
        final String[] q = Text.clave(Text.norm(texto));
        final ArrayList<int[]> c = new ArrayList<int[]>();
        for (int i = 0; i < d.nNames; i++) {
            int p = puntaje(q, calleClave[i]);
            if (p >= 0) c.add(new int[]{p, d.names[i].length(), i});
        }
        Collections.sort(c, new Comparator<int[]>() {
            public int compare(int[] a, int[] b) {
                if (a[0] != b[0]) return a[0] - b[0];
                if (a[1] != b[1]) return a[1] - b[1];
                return a[2] - b[2];
            }
        });
        ArrayList<Integer> r = new ArrayList<Integer>();
        for (int i = 0; i < c.size() && i < limite; i++) r.add(c.get(i)[2]);
        return r;
    }

    // ------------------------------------------------------------------ puntos de una calle

    /** Un punto de la calle: el tramo más cercano a la referencia. null si la calle no tiene tramos. */
    private double[] puntoDeCalle(int nombre, double rLat, double rLon) {
        double mejor = Double.MAX_VALUE;
        double[] res = null;
        for (int k = d.nameLinkStart[nombre]; k < d.nameLinkStart[nombre + 1]; k++) {
            int l = d.nameLinkList[k];
            int n = d.puntos(l);
            int m = n / 2;
            double la = d.latDe(l, m) * 1e-6, lo = d.lonDe(l, m) * 1e-6;
            double dd = Geo.dist(la, lo, rLat, rLon);
            if (dd < mejor) { mejor = dd; res = new double[]{la, lo, dd}; }
        }
        return res;
    }

    private int primeraDireccion(int calle) {
        int lo = 0, hi = d.nAddr;
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (d.addrStreet.get(mid) < calle) lo = mid + 1; else hi = mid;
        }
        return lo;
    }

    // ------------------------------------------------------------------ búsqueda

    public List<Lugar> buscar(String consulta, int max, double rLat, double rLon) {
        ArrayList<Lugar> out = new ArrayList<Lugar>();
        String qn = Text.norm(consulta);
        if (qn.isEmpty()) return out;

        Matcher mc = CRUCE.matcher(qn);
        if (mc.matches()) {
            cruces(mc.group(1), mc.group(2), rLat, rLon, out);
            if (!out.isEmpty()) return out;
        }
        Lugar respaldo = null;
        Matcher ma = ALTURA.matcher(qn);
        if (ma.matches()) {
            ArrayList<Lugar> dir = new ArrayList<Lugar>();
            respaldo = direcciones(ma.group(1), Integer.parseInt(ma.group(2)), rLat, rLon, dir);
            if (!dir.isEmpty()) return dir;
        }
        nombres(qn, max, rLat, rLon, out);
        if (out.isEmpty() && respaldo != null) out.add(respaldo);
        return out;
    }

    private void cruces(String a, String b, double rLat, double rLon, List<Lugar> out) {
        List<Integer> ia = buscarCalles(a, 6), ib = buscarCalles(b, 6);
        if (ia.isEmpty() || ib.isEmpty()) return;
        HashMap<Integer, Integer> deA = new HashMap<Integer, Integer>();
        for (int id : ia) {
            for (int k = d.nameLinkStart[id]; k < d.nameLinkStart[id + 1]; k++) {
                int l = d.nameLinkList[k];
                deA.put(d.lA[l], id);
                deA.put(d.lB[l], id);
            }
        }
        HashMap<Integer, int[]> hallados = new HashMap<Integer, int[]>();
        for (int id : ib) {
            for (int k = d.nameLinkStart[id]; k < d.nameLinkStart[id + 1]; k++) {
                int l = d.nameLinkList[k];
                int[] vs = {d.lA[l], d.lB[l]};
                for (int v : vs) {
                    Integer na = deA.get(v);
                    if (na != null && na.intValue() != id) hallados.put(v, new int[]{na, id});
                }
            }
        }
        ArrayList<Lugar> c = new ArrayList<Lugar>();
        for (Map.Entry<Integer, int[]> e : hallados.entrySet()) {
            int v = e.getKey();
            Lugar x = new Lugar();
            x.lat = d.vLat[v] * 1e-6;
            x.lon = d.vLon[v] * 1e-6;
            x.tipo = ESQUINA;
            x.titulo = d.names[e.getValue()[0]] + " y " + d.names[e.getValue()[1]];
            x.detalle = "Esquina";
            x.distancia = Geo.dist(x.lat, x.lon, rLat, rLon);
            c.add(x);
        }
        ordenarPorDistancia(c);
        for (Lugar x : c) {
            boolean cerca = false;
            for (Lugar y : out) if (Geo.dist(x.lat, x.lon, y.lat, y.lon) < 150) cerca = true;
            if (!cerca) out.add(x);
            if (out.size() >= 3) break;
        }
    }

    private static void ordenarPorDistancia(List<Lugar> l) {
        Collections.sort(l, new Comparator<Lugar>() {
            public int compare(Lugar a, Lugar b) { return Double.compare(a.distancia, b.distancia); }
        });
    }

    /** Devuelve un resultado "de respaldo" (la calle sola) cuando no hay alturas cargadas. */
    private Lugar direcciones(String calleTxt, int numero, double rLat, double rLon, List<Lugar> out) {
        List<Integer> ids = buscarCalles(calleTxt, 8);
        if (ids.isEmpty()) return null;
        ArrayList<Integer> idx = new ArrayList<Integer>();
        for (int id : ids) {
            for (int i = primeraDireccion(id); i < d.nAddr && d.addrStreet.get(i) == id; i++) idx.add(i);
        }
        if (idx.isEmpty()) {
            double[] p = puntoDeCalle(ids.get(0), rLat, rLon);
            if (p == null) return null;
            Lugar x = new Lugar();
            x.titulo = d.names[ids.get(0)] + " " + numero;
            x.detalle = "No tengo las alturas de esta calle: te llevo a la calle";
            x.lat = p[0]; x.lon = p[1]; x.tipo = CALLE; x.distancia = p[2];
            return x;
        }
        // priorizar lo cercano a la referencia (hay calles con el mismo nombre en muchas localidades)
        ArrayList<Integer> cerca = new ArrayList<Integer>();
        for (int i : idx) {
            double dd = Geo.dist(d.addrLat.get(i) * 1e-6, d.addrLon.get(i) * 1e-6, rLat, rLon);
            if (dd < 25000) cerca.add(i);
        }
        if (cerca.isEmpty()) cerca = idx;

        ArrayList<Lugar> exactas = new ArrayList<Lugar>();
        for (int i : cerca) {
            if (d.addrNum.get(i) == numero) {
                Lugar x = new Lugar();
                x.lat = d.addrLat.get(i) * 1e-6;
                x.lon = d.addrLon.get(i) * 1e-6;
                x.tipo = DIRECCION;
                x.titulo = d.names[d.addrStreet.get(i)] + " " + numero;
                x.detalle = "Dirección";
                x.distancia = Geo.dist(x.lat, x.lon, rLat, rLon);
                exactas.add(x);
            }
        }
        if (!exactas.isEmpty()) {
            ordenarPorDistancia(exactas);
            for (Lugar x : exactas) {
                boolean repetida = false;
                for (Lugar y : out) if (Geo.dist(x.lat, x.lon, y.lat, y.lon) < 1500) repetida = true;
                if (!repetida) out.add(x);
                if (out.size() >= 3) break;
            }
            return null;
        }

        // altura que no está cargada: se calcula entre las vecinas de la misma calle
        int ancla = -1;
        long mejorDif = Long.MAX_VALUE;
        double mejorDist = Double.MAX_VALUE;
        for (int i : cerca) {
            long dif = Math.abs((long) d.addrNum.get(i) - numero);
            double dd = Geo.dist(d.addrLat.get(i) * 1e-6, d.addrLon.get(i) * 1e-6, rLat, rLon);
            if (dif < mejorDif || (dif == mejorDif && dd < mejorDist)) { mejorDif = dif; mejorDist = dd; ancla = i; }
        }
        double aLat = d.addrLat.get(ancla) * 1e-6, aLon = d.addrLon.get(ancla) * 1e-6;
        ArrayList<Integer> grupo = new ArrayList<Integer>();
        for (int i : cerca) if (Geo.dist(d.addrLat.get(i) * 1e-6, d.addrLon.get(i) * 1e-6, aLat, aLon) < 12000) grupo.add(i);
        ArrayList<Integer> mismaPar = new ArrayList<Integer>();
        for (int i : grupo) if ((d.addrNum.get(i) & 1) == (numero & 1)) mismaPar.add(i);
        List<Integer> pool = mismaPar.size() >= 2 ? mismaPar : grupo;
        int lo = -1, hi = -1;
        for (int i : pool) {
            int n = d.addrNum.get(i);
            if (n < numero && (lo < 0 || n > d.addrNum.get(lo))) lo = i;
            if (n > numero && (hi < 0 || n < d.addrNum.get(hi))) hi = i;
        }
        double lat, lon;
        if (lo >= 0 && hi >= 0
                && Geo.dist(d.addrLat.get(lo) * 1e-6, d.addrLon.get(lo) * 1e-6, d.addrLat.get(hi) * 1e-6, d.addrLon.get(hi) * 1e-6) < 10000
                && d.addrNum.get(hi) - d.addrNum.get(lo) <= 4000) {
            double f = (numero - d.addrNum.get(lo)) / (double) (d.addrNum.get(hi) - d.addrNum.get(lo));
            lat = (d.addrLat.get(lo) + f * (d.addrLat.get(hi) - d.addrLat.get(lo))) * 1e-6;
            lon = (d.addrLon.get(lo) + f * (d.addrLon.get(hi) - d.addrLon.get(lo))) * 1e-6;
        } else {
            lat = aLat;
            lon = aLon;
        }
        Lugar x = new Lugar();
        x.lat = lat; x.lon = lon; x.tipo = DIRECCION;
        x.titulo = d.names[d.addrStreet.get(ancla)] + " " + numero;
        x.detalle = "Altura aproximada (esa altura no está cargada en el mapa)";
        x.distancia = Geo.dist(lat, lon, rLat, rLon);
        out.add(x);
        return null;
    }

    private void nombres(String qn, int max, double rLat, double rLon, List<Lugar> out) {
        String[] q = Text.clave(qn);
        ArrayList<Lugar> todos = new ArrayList<Lugar>();

        // calles
        ArrayList<int[]> calles = new ArrayList<int[]>();
        for (int i = 0; i < d.nNames; i++) {
            int p = puntaje(q, calleClave[i]);
            if (p >= 0) calles.add(new int[]{p, d.names[i].length(), i});
        }
        Collections.sort(calles, new Comparator<int[]>() {
            public int compare(int[] a, int[] b) {
                if (a[0] != b[0]) return a[0] - b[0];
                return a[1] - b[1];
            }
        });
        for (int i = 0; i < calles.size() && i < 5; i++) {
            int id = calles.get(i)[2];
            double[] p = puntoDeCalle(id, rLat, rLon);
            if (p == null) {
                int a = primeraDireccion(id);
                if (a < d.nAddr && d.addrStreet.get(a) == id) p = new double[]{d.addrLat.get(a) * 1e-6, d.addrLon.get(a) * 1e-6, 0};
            }
            if (p == null) continue;
            Lugar x = new Lugar();
            x.titulo = d.names[id];
            x.detalle = "Calle";
            x.lat = p[0]; x.lon = p[1]; x.tipo = CALLE;
            x.distancia = Geo.dist(p[0], p[1], rLat, rLon);
            x.puntaje = calles.get(i)[0];
            todos.add(x);
        }

        // lugares y barrios
        if (d.nPoi > 0) {
            prepararLugares();
            for (int i = 0; i < d.nPoi; i++) {
                int p = puntaje(q, lugarClave[i]);
                if (p < 0) continue;
                Lugar x = new Lugar();
                x.titulo = lugarNombre[i];
                int k = d.poiKind.get(i);
                x.detalle = RUBROS[k >= 0 && k < RUBROS.length ? k : 0];
                x.lat = d.poiLat.get(i) * 1e-6;
                x.lon = d.poiLon.get(i) * 1e-6;
                x.tipo = LUGAR;
                x.distancia = Geo.dist(x.lat, x.lon, rLat, rLon);
                x.puntaje = p;
                todos.add(x);
            }
        }
        Collections.sort(todos, new Comparator<Lugar>() {
            public int compare(Lugar a, Lugar b) {
                if (a.puntaje != b.puntaje) return a.puntaje - b.puntaje;
                return Double.compare(a.distancia, b.distancia);
            }
        });
        for (int i = 0; i < todos.size() && out.size() < max; i++) out.add(todos.get(i));
    }
}
