package com.mapaoffline.gps.nav;

import java.util.ArrayList;
import java.util.List;

/** Una ruta calculada: línea para dibujar, distancia, tiempo y las indicaciones giro a giro. */
public final class Route {
    public static final int SALIDA = 0, SEGUI = 1, LIG_DER = 2, DER = 3, BRUSCO_DER = 4,
            LIG_IZQ = 5, IZQ = 6, BRUSCO_IZQ = 7, GIRO_U = 8, ROTONDA = 9, LLEGADA = 10;

    public static final class Paso {
        public int tipo;
        public String calle = "";
        public double lat, lon;
        /** Metros recorridos sobre la ruta hasta este punto. */
        public double desde;
        /** Metros hasta la siguiente indicación. */
        public double distancia;
        public int salida;

        /** Indicación escrita, sin la distancia. */
        public String texto() {
            String en = calle.isEmpty() ? "" : " en " + calle;
            String por = calle.isEmpty() ? "" : " por " + calle;
            switch (tipo) {
                case SALIDA: return "Salí" + por;
                case SEGUI: return "Seguí" + por;
                case LIG_DER: return "Doblá ligeramente a la derecha" + en;
                case DER: return "Doblá a la derecha" + en;
                case BRUSCO_DER: return "Doblá a la derecha, giro cerrado" + en;
                case LIG_IZQ: return "Doblá ligeramente a la izquierda" + en;
                case IZQ: return "Doblá a la izquierda" + en;
                case BRUSCO_IZQ: return "Doblá a la izquierda, giro cerrado" + en;
                case GIRO_U: return "Hacé un giro en U";
                case ROTONDA: return "En la rotonda, tomá la " + salida + "ª salida" + (calle.isEmpty() ? "" : " hacia " + calle);
                default: return "Llegaste a tu destino";
            }
        }
    }

    public double[] lat, lon, cum;
    public double distancia, tiempo;
    public final List<Paso> pasos = new ArrayList<Paso>();

    /** Dónde está un punto respecto de la ruta. */
    public static final class Ubicacion {
        public int segmento;
        public double progreso;   // metros recorridos
        public double fuera;      // metros hasta la línea de la ruta
    }

    public int puntos() { return lat.length; }

    /** Punto más cercano de la ruta entre los segmentos [desde, hasta]. */
    public Ubicacion ubicar(double pLat, double pLon, int desde, int hasta) {
        int n = lat.length;
        if (n < 2) return null;
        if (desde < 0) desde = 0;
        if (hasta > n - 2) hasta = n - 2;
        double kx = Geo.M_POR_GRADO * Math.cos(Math.toRadians(pLat));
        double ky = Geo.M_POR_GRADO;
        Ubicacion mejor = null;
        for (int i = desde; i <= hasta; i++) {
            double ax = (lon[i] - pLon) * kx, ay = (lat[i] - pLat) * ky;
            double bx = (lon[i + 1] - pLon) * kx, by = (lat[i + 1] - pLat) * ky;
            double dx = bx - ax, dy = by - ay;
            double seg = Math.sqrt(dx * dx + dy * dy);
            double t = seg < 1e-9 ? 0 : (-ax * dx - ay * dy) / (seg * seg);
            if (t < 0) t = 0;
            if (t > 1) t = 1;
            double px = ax + t * dx, py = ay + t * dy;
            double d = Math.sqrt(px * px + py * py);
            if (mejor == null || d < mejor.fuera) {
                if (mejor == null) mejor = new Ubicacion();
                mejor.fuera = d;
                mejor.segmento = i;
                mejor.progreso = cum[i] + t * seg;
            }
        }
        return mejor;
    }

    public Ubicacion ubicar(double pLat, double pLon) {
        return ubicar(pLat, pLon, 0, lat.length);
    }
}
